package s493x039



import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = true)
class CadastroController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond Cadastro.list(params), model:[cadastroInstanceCount: Cadastro.count()]
    }

    def show(Cadastro cadastroInstance) {
        respond cadastroInstance
    }

    def create() {
        respond new Cadastro(params)
    }

    @Transactional
    def save(Cadastro cadastroInstance) {
        if (cadastroInstance == null) {
            notFound()
            return
        }

        if (cadastroInstance.hasErrors()) {
            respond cadastroInstance.errors, view:'create'
            return
        }

        cadastroInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'cadastro.label', default: 'Cadastro'), cadastroInstance.id])
                redirect cadastroInstance
            }
            '*' { respond cadastroInstance, [status: CREATED] }
        }
    }

    def edit(Cadastro cadastroInstance) {
        respond cadastroInstance
    }

    @Transactional
    def update(Cadastro cadastroInstance) {
        if (cadastroInstance == null) {
            notFound()
            return
        }

        if (cadastroInstance.hasErrors()) {
            respond cadastroInstance.errors, view:'edit'
            return
        }

        cadastroInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'Cadastro.label', default: 'Cadastro'), cadastroInstance.id])
                redirect cadastroInstance
            }
            '*'{ respond cadastroInstance, [status: OK] }
        }
    }

    @Transactional
    def delete(Cadastro cadastroInstance) {

        if (cadastroInstance == null) {
            notFound()
            return
        }

        cadastroInstance.delete flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'Cadastro.label', default: 'Cadastro'), cadastroInstance.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'cadastro.label', default: 'Cadastro'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
