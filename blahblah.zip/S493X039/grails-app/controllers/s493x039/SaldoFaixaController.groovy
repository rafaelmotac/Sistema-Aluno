package s493x039



import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = true)
class SaldoFaixaController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
		def a = SaldoFaixa.findAllByDt_prcIsNull(params)
       // respond SaldoFaixa.list(params), model:[saldoFaixaInstanceCount: SaldoFaixa.count()]
		respond a, model:[saldoFaixaInstanceCount: a.size()]
    }

    def show(SaldoFaixa saldoFaixaInstance) {
        respond saldoFaixaInstance
    }

    def busca() {
       // respond new SaldoFaixa(params)
    }
	
	def mostrar(params){
		def saldosFaixa = SaldoFaixa.find("FROM SaldoFaixa s where s.nomeOpr = :nome AND s.dt_ref = :dtRef",[nome:params.nomeOpr,dtRef:params.dt_ref])
	
		render(template:'resultado', model:[saldos:saldosFaixa])
	}
	
	def submeter(SaldoFaixa saldoFaixaInstance) {
		def novo = new SaldoFaixa()
		novo.nomeOpr = saldoFaixaInstance.nomeOpr
		novo.dt_prc = Calendar.getInstance()
		novo.cd_ar_opr	=	saldoFaixaInstance.cd_ar_opr
		novo.cd_ag	=	saldoFaixaInstance.cd_ag
		novo.cd_ctr	=	saldoFaixaInstance.cd_ctr
		novo.nr_ope	=	saldoFaixaInstance.nr_ope
		def dataAtual = Calendar.getInstance()
		
		
		
		dataAtual.set(Calendar.DAY_OF_MONTH, dataAtual.getActualMaximum(dataAtual.DAY_OF_MONTH))
		
		
		novo.dt_ref	=	saldoFaixaInstance.dt_ref
		novo.dt_trm_car	=	saldoFaixaInstance.dt_trm_car
		novo.nr_prs	=	saldoFaixaInstance.nr_prs
		novo.vr_tx_jrs	=	saldoFaixaInstance.vr_tx_jrs
		novo.sd_ini_rap	=	saldoFaixaInstance.sd_ini_rap
		novo.sd_vin_f01	=	saldoFaixaInstance.sd_vin_f01
		novo.sd_vin_f02	=	saldoFaixaInstance.sd_vin_f02
		novo.sd_vin_f03	=	saldoFaixaInstance.sd_vin_f03
		novo.sd_vin_f04	=	saldoFaixaInstance.sd_vin_f04
		novo.sd_vin_f05	=	saldoFaixaInstance.sd_vin_f05
		novo.sd_vin_f06	=	saldoFaixaInstance.sd_vin_f06
		novo.sd_vin_f07	=	saldoFaixaInstance.sd_vin_f07
		novo.sd_vin_f08	=	saldoFaixaInstance.sd_vin_f08
		novo.sd_vin_f09	=	saldoFaixaInstance.sd_vin_f09
		novo.sd_vin_f10	=	saldoFaixaInstance.sd_vin_f10
		novo.sd_vin_f11	=	saldoFaixaInstance.sd_vin_f11
		novo.sd_ven_f01	=	saldoFaixaInstance.sd_ven_f01
		novo.sd_ven_f02	=	saldoFaixaInstance.sd_ven_f02
		novo.sd_ven_f03	=	saldoFaixaInstance.sd_ven_f03
		novo.sd_ven_f04	=	saldoFaixaInstance.sd_ven_f04
		novo.sd_ven_f05	=	saldoFaixaInstance.sd_ven_f05
		novo.sd_ven_f06	=	saldoFaixaInstance.sd_ven_f06
		novo.sd_ven_f07	=	saldoFaixaInstance.sd_ven_f07
		novo.sd_ven_f08	=	saldoFaixaInstance.sd_ven_f08
		novo.sd_ven_f09	=	saldoFaixaInstance.sd_ven_f09
		novo.sd_ven_f10	=	saldoFaixaInstance.sd_ven_f10
		novo.sd_ven_f11	=	saldoFaixaInstance.sd_ven_f11
		novo.sd_ven_f12	=	saldoFaixaInstance.sd_ven_f12
		novo.vr_prj_f01	=	saldoFaixaInstance.vr_prj_f01
		novo.vr_prj_f02	=	saldoFaixaInstance.vr_prj_f02
		novo.vr_prj	=	saldoFaixaInstance.vr_prj
		novo.vr_rec_cli	=	saldoFaixaInstance.vr_rec_cli
		novo.vr_eft_rap	=	saldoFaixaInstance.vr_eft_rap
		novo.vr_rnd_nrm	=	saldoFaixaInstance.vr_rnd_nrm
		novo.vr_prj_f03	=	saldoFaixaInstance.vr_prj_f03
		novo.cd_idx_cm	=	saldoFaixaInstance.cd_idx_cm
		novo.vr_rec_bem	=	saldoFaixaInstance.vr_rec_bem
		novo.vr_rec_rng	=	saldoFaixaInstance.vr_rec_rng
		novo.vr_pcl_pgo	=	saldoFaixaInstance.vr_pcl_pgo
		novo.vr_pcl_atr	=	saldoFaixaInstance.vr_pcl_atr
		novo.vr_atr_ant	=	saldoFaixaInstance.vr_atr_ant
		novo.vr_rec_out	=	saldoFaixaInstance.vr_rec_out
		novo.sd_rap_vin_f01	=	saldoFaixaInstance.sd_rap_vin_f01
		novo.sd_rap_vin_f02	=	saldoFaixaInstance.sd_rap_vin_f02
		novo.sd_rap_vin_f03	=	saldoFaixaInstance.sd_rap_vin_f03
		novo.sd_rap_vin_f04	=	saldoFaixaInstance.sd_rap_vin_f04
		novo.sd_rap_vin_f05	=	saldoFaixaInstance.sd_rap_vin_f05
		novo.sd_rap_vin_f06	=	saldoFaixaInstance.sd_rap_vin_f06
		novo.sd_rap_vin_f07	=	saldoFaixaInstance.sd_rap_vin_f07
		novo.sd_rap_vin_f08	=	saldoFaixaInstance.sd_rap_vin_f08
		novo.sd_rap_vin_f09	=	saldoFaixaInstance.sd_rap_vin_f09
		novo.sd_rap_vin_f10	=	saldoFaixaInstance.sd_rap_vin_f10
		novo.sd_rap_vin_f11	=	saldoFaixaInstance.sd_rap_vin_f11
		novo.sd_rap_ven_f01	=	saldoFaixaInstance.sd_rap_ven_f01
		novo.sd_rap_ven_f02	=	saldoFaixaInstance.sd_rap_ven_f02
		novo.sd_rap_ven_f03	=	saldoFaixaInstance.sd_rap_ven_f03
		novo.sd_rap_ven_f04	=	saldoFaixaInstance.sd_rap_ven_f04
		novo.sd_rap_ven_f05	=	saldoFaixaInstance.sd_rap_ven_f05
		novo.sd_rap_ven_f06	=	saldoFaixaInstance.sd_rap_ven_f06
		novo.sd_rap_ven_f07	=	saldoFaixaInstance.sd_rap_ven_f07
		novo.sd_rap_ven_f08	=	saldoFaixaInstance.sd_rap_ven_f08
		novo.sd_rap_ven_f09	=	saldoFaixaInstance.sd_rap_ven_f09
		novo.sd_rap_ven_f10	=	saldoFaixaInstance.sd_rap_ven_f10
		novo.sd_rap_ven_f11	=	saldoFaixaInstance.sd_rap_ven_f11
		novo.sd_rap_ven_f12	=	saldoFaixaInstance.sd_rap_ven_f12
		
		respond novo
	}



    @Transactional
    def save(SaldoFaixa saldoFaixaInstance) {
        if (saldoFaixaInstance == null) {
            notFound()
            return
        }

        if (saldoFaixaInstance.hasErrors()) {
            respond saldoFaixaInstance.errors, view:'create'
            return
        }

        saldoFaixaInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'saldoFaixa.label', default: 'SaldoFaixa'), saldoFaixaInstance.id])
                redirect saldoFaixaInstance
            }
            '*' { respond saldoFaixaInstance, [status: CREATED] }
        }
    }

    def edit(SaldoFaixa saldoFaixaInstance) {
        respond saldoFaixaInstance
    }

    @Transactional
    def update(SaldoFaixa saldoFaixaInstance) {
        if (saldoFaixaInstance == null) {
            notFound()
            return
        }

        if (saldoFaixaInstance.hasErrors()) {
            respond saldoFaixaInstance.errors, view:'edit'
            return
        }

        saldoFaixaInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'SaldoFaixa.label', default: 'SaldoFaixa'), saldoFaixaInstance.id])
                redirect saldoFaixaInstance
            }
            '*'{ respond saldoFaixaInstance, [status: OK] }
        }
    }

    @Transactional
    def delete(SaldoFaixa saldoFaixaInstance) {

        if (saldoFaixaInstance == null) {
            notFound()
            return
        }

        saldoFaixaInstance.delete flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'SaldoFaixa.label', default: 'SaldoFaixa'), saldoFaixaInstance.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'saldoFaixa.label', default: 'SaldoFaixa'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
