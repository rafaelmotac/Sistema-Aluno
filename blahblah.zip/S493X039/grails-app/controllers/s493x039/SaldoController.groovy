package s493x039



import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = true)
class SaldoController {
	
	def saldosService

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
		/*def dataCalendar = Calendar.getInstance()
		dataCalendar.set(2016, Calendar.MAY, 31, 0, 0, 0)	
		def data = new Date()
		
		data.setTime(dataCalendar.getTimeInMillis())
		
		println data.toString()*/
		
		def dataMaior = Saldo.executeQuery("select max(s.dt_ref) from Saldo s")
	
		//def a = Saldo.findAllByDt_prcIsNull(params)
		def a = Saldo.findAll("FROM Saldo s where s.dt_ref = :dtRef",[dtRef:dataMaior])
		
        //respond Saldo.list(params), model:[saldoInstanceCount: Saldo.count()]
		respond a, model:[saldoInstanceCount: a.size()]
    }
	
	def busca(){
		//respond new Saldo(params)
	}
	

    def show(Saldo saldoInstance) {
		respond saldoInstance
    }
	
	def mostrar(params){
		def saldos = Saldo.find("FROM Saldo s where s.nomeOpr = :nome AND s.dt_ref = :dtRef",[nome:params.nomeOpr,dtRef:params.dt_ref])
		render(template:'resultado', model:[saldos:saldos])
	}

    def submeter(Saldo saldoInstance) {
		
        respond saldosService.submeterSaldo(saldoInstance)
    }

    @Transactional
    def save(Saldo saldoInstance) {
		saldoInstance.dt_prc = Calendar.getInstance().getTime()
        if (saldoInstance == null) {
            notFound()
            return
        }

        if (saldoInstance.hasErrors()) {
            respond saldoInstance.errors, view:'edit'
            return
        }

        saldoInstance.save(flush:true)
		

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'saldo.label', default: 'Saldo'), saldoInstance.id])
                redirect saldoInstance
            }
            '*' { respond saldoInstance, [status: CREATED] }
        }
    }
		

    def edit(Saldo saldoInstance) {	
       respond saldoInstance
    }

    @Transactional
    def update(Saldo saldoInstance) {
        if (saldoInstance == null) {
            notFound()
            return
        }

        if (saldoInstance.hasErrors()) {
            respond saldoInstance.errors, view:'edit'
            return
        }

        saldoInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'Saldo.label', default: 'Saldo'), saldoInstance.id])
                redirect saldoInstance
            }
            '*'{ respond saldoInstance, [status: OK] }
        }
    }

    @Transactional
    def delete(Saldo saldoInstance) {

        if (saldoInstance == null) {
            notFound()
            return
        }

        saldoInstance.delete flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'Saldo.label', default: 'Saldo'), saldoInstance.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'saldo.label', default: 'Saldo'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
