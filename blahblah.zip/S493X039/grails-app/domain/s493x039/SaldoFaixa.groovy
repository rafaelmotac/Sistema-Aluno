package s493x039

class SaldoFaixa {
	String nomeOpr
	Date dt_prc
	String	cd_ar_opr
	BigDecimal	cd_ag
	String	cd_ctr
	BigDecimal	nr_ope
	Date	dt_ref
	Date	dt_trm_car
	BigDecimal	nr_prs
	BigDecimal	vr_tx_jrs
	Date	dt_ini_rap
	BigDecimal	sd_ini_rap
	BigDecimal	sd_vin_f01
	BigDecimal	sd_vin_f02
	BigDecimal	sd_vin_f03
	BigDecimal	sd_vin_f04
	BigDecimal	sd_vin_f05
	BigDecimal	sd_vin_f06
	BigDecimal	sd_vin_f07
	BigDecimal	sd_vin_f08
	BigDecimal	sd_vin_f09
	BigDecimal	sd_vin_f10
	BigDecimal	sd_vin_f11
	BigDecimal	sd_ven_f01
	BigDecimal	sd_ven_f02
	BigDecimal	sd_ven_f03
	BigDecimal	sd_ven_f04
	BigDecimal	sd_ven_f05
	BigDecimal	sd_ven_f06
	BigDecimal	sd_ven_f07
	BigDecimal	sd_ven_f08
	BigDecimal	sd_ven_f09
	BigDecimal	sd_ven_f10
	BigDecimal	sd_ven_f11
	BigDecimal	sd_ven_f12
	BigDecimal	vr_prj_f01
	BigDecimal	vr_prj_f02
	BigDecimal	vr_prj
	BigDecimal	vr_rec_cli
	BigDecimal	vr_eft_rap
	BigDecimal	vr_rnd_nrm
	BigDecimal	vr_prj_f03
	BigDecimal	cd_idx_cm
	BigDecimal	cd_idx_jrs
	BigDecimal	vr_rec_bem
	BigDecimal	vr_rec_rng
	Date	dt_pcl_ven
	BigDecimal	vr_pcl_pgo
	BigDecimal	vr_pcl_atr
	BigDecimal	vr_atr_ant
	BigDecimal	vr_rec_out
	BigDecimal	sd_rap_vin_f01
	BigDecimal	sd_rap_vin_f02
	BigDecimal	sd_rap_vin_f03
	BigDecimal	sd_rap_vin_f04
	BigDecimal	sd_rap_vin_f05
	BigDecimal	sd_rap_vin_f06
	BigDecimal	sd_rap_vin_f07
	BigDecimal	sd_rap_vin_f08
	BigDecimal	sd_rap_vin_f09
	BigDecimal	sd_rap_vin_f10
	BigDecimal	sd_rap_vin_f11
	BigDecimal	sd_rap_ven_f01
	BigDecimal	sd_rap_ven_f02
	BigDecimal	sd_rap_ven_f03
	BigDecimal	sd_rap_ven_f04
	BigDecimal	sd_rap_ven_f05
	BigDecimal	sd_rap_ven_f06
	BigDecimal	sd_rap_ven_f07
	BigDecimal	sd_rap_ven_f08
	BigDecimal	sd_rap_ven_f09
	BigDecimal	sd_rap_ven_f10
	BigDecimal	sd_rap_ven_f11
	BigDecimal	sd_rap_ven_f12
	
	static mapping = {
		version false
		nomeOpr column:"nome", sqlType:"varchar"
		dt_prc column:"DT_PRC", sqlType:"datetime"
		cd_ar_opr	column:	"CD_AR_OPR"	,sqlType:"char"	,length:1
		cd_ag	column:	"CD_AG"	,sqlType:"decimal"	,precision:4
		cd_ctr	column:	"CD_CTR"	,sqlType:"char"	,length:10
		nr_ope	column:	"NR_OPE"	,sqlType:"decimal"	,precision:3
		dt_ref	column:	"DT_REF"	,sqlType:"datetime"
		dt_trm_car	column:	"DT_TRM_CAR"	,sqlType:"datetime"
		nr_prs	column:	"NR_PRS"	,sqlType:"decimal"	,precision:3
		vr_tx_jrs	column:	"VR_TX_JRS"	,sqlType:"decimal"	,precision:9, scale:4
		dt_ini_rap	column:	"DT_INI_RAP"	,sqlType:"datetime"
		sd_ini_rap	column:	"SD_INI_RAP"	,sqlType:"decimal"	,precision:17, scale:2
		sd_vin_f01	column:	"SD_VIN_F01"	,sqlType:"decimal"	,precision:17, scale:2
		sd_vin_f02	column:	"SD_VIN_F02"	,sqlType:"decimal"	,precision:17, scale:2
		sd_vin_f03	column:	"SD_VIN_F03"	,sqlType:"decimal"	,precision:17, scale:2
		sd_vin_f04	column:	"SD_VIN_F04"	,sqlType:"decimal"	,precision:17, scale:2
		sd_vin_f05	column:	"SD_VIN_F05"	,sqlType:"decimal"	,precision:17, scale:2
		sd_vin_f06	column:	"SD_VIN_F06"	,sqlType:"decimal"	,precision:17, scale:2
		sd_vin_f07	column:	"SD_VIN_F07"	,sqlType:"decimal"	,precision:17, scale:2
		sd_vin_f08	column:	"SD_VIN_F08"	,sqlType:"decimal"	,precision:17, scale:2
		sd_vin_f09	column:	"SD_VIN_F09"	,sqlType:"decimal"	,precision:17, scale:2
		sd_vin_f10	column:	"SD_VIN_F10"	,sqlType:"decimal"	,precision:17, scale:2
		sd_vin_f11	column:	"SD_VIN_F11"	,sqlType:"decimal"	,precision:17, scale:2
		sd_ven_f01	column:	"SD_VEN_F01"	,sqlType:"decimal"	,precision:17, scale:2
		sd_ven_f02	column:	"SD_VEN_F02"	,sqlType:"decimal"	,precision:17, scale:2
		sd_ven_f03	column:	"SD_VEN_F03"	,sqlType:"decimal"	,precision:17, scale:2
		sd_ven_f04	column:	"SD_VEN_F04"	,sqlType:"decimal"	,precision:17, scale:2
		sd_ven_f05	column:	"SD_VEN_F05"	,sqlType:"decimal"	,precision:17, scale:2
		sd_ven_f06	column:	"SD_VEN_F06"	,sqlType:"decimal"	,precision:17, scale:2
		sd_ven_f07	column:	"SD_VEN_F07"	,sqlType:"decimal"	,precision:17, scale:2
		sd_ven_f08	column:	"SD_VEN_F08"	,sqlType:"decimal"	,precision:17, scale:2
		sd_ven_f09	column:	"SD_VEN_F09"	,sqlType:"decimal"	,precision:17, scale:2
		sd_ven_f10	column:	"SD_VEN_F10"	,sqlType:"decimal"	,precision:17, scale:2
		sd_ven_f11	column:	"SD_VEN_F11"	,sqlType:"decimal"	,precision:17, scale:2
		sd_ven_f12	column:	"SD_VEN_F12"	,sqlType:"decimal"	,precision:17, scale:2
		vr_prj_f01	column:	"VR_PRJ_F01"	,sqlType:"decimal"	,precision:17, scale:2
		vr_prj_f02	column:	"VR_PRJ_F02"	,sqlType:"decimal"	,precision:17, scale:2
		vr_prj	column:	"VR_PRJ"	,sqlType:"decimal"	,precision:17, scale:2
		vr_rec_cli	column:	"VR_REC_CLI"	,sqlType:"decimal"	,precision:17, scale:2
		vr_eft_rap	column:	"VR_EFT_RAP"	,sqlType:"decimal"	,precision:17, scale:2
		vr_rnd_nrm	column:	"VR_RND_NRM"	,sqlType:"decimal"	,precision:17, scale:2
		vr_prj_f03	column:	"VR_PRJ_F03"	,sqlType:"decimal"	,precision:17, scale:2
		cd_idx_cm	column:	"CD_IDX_CM"	,sqlType:"decimal"	,precision:5
		cd_idx_jrs	column:	"CD_IDX_JRS"	,sqlType:"decimal"	,precision:5
		vr_rec_bem	column:	"VR_REC_BEM"	,sqlType:"decimal"	,precision:17, scale:2
		vr_rec_rng	column:	"VR_REC_RNG"	,sqlType:"decimal"	,precision:17, scale:2
		dt_pcl_ven	column:	"DT_PCL_VEN"	,sqlType:"datetime"
		vr_pcl_pgo	column:	"VR_PCL_PGO"	,sqlType:"decimal"	,precision:17, scale:2
		vr_pcl_atr	column:	"VR_PCL_ATR"	,sqlType:"decimal"	,precision:17, scale:2
		vr_atr_ant	column:	"VR_ATR_ANT"	,sqlType:"decimal"	,precision:17, scale:2
		vr_rec_out	column:	"VR_REC_OUT"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_vin_f01	column:	"SD_RAP_VIN_F01"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_vin_f02	column:	"SD_RAP_VIN_F02"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_vin_f03	column:	"SD_RAP_VIN_F03"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_vin_f04	column:	"SD_RAP_VIN_F04"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_vin_f05	column:	"SD_RAP_VIN_F05"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_vin_f06	column:	"SD_RAP_VIN_F06"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_vin_f07	column:	"SD_RAP_VIN_F07"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_vin_f08	column:	"SD_RAP_VIN_F08"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_vin_f09	column:	"SD_RAP_VIN_F09"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_vin_f10	column:	"SD_RAP_VIN_F10"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_vin_f11	column:	"SD_RAP_VIN_F11"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_ven_f01	column:	"SD_RAP_VEN_F01"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_ven_f02	column:	"SD_RAP_VEN_F02"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_ven_f03	column:	"SD_RAP_VEN_F03"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_ven_f04	column:	"SD_RAP_VEN_F04"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_ven_f05	column:	"SD_RAP_VEN_F05"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_ven_f06	column:	"SD_RAP_VEN_F06"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_ven_f07	column:	"SD_RAP_VEN_F07"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_ven_f08	column:	"SD_RAP_VEN_F08"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_ven_f09	column:	"SD_RAP_VEN_F09"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_ven_f10	column:	"SD_RAP_VEN_F10"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_ven_f11	column:	"SD_RAP_VEN_F11"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_ven_f12	column:	"SD_RAP_VEN_F12"	,sqlType:"decimal"	,precision:17, scale:2
		
	}
    static constraints = {
		cd_ar_opr	nullable:false,blank:false,maxSize:1
		cd_ag	nullable:false,blank:false,maxSize:4
		cd_ctr	nullable:false,blank:false,maxSize:10
		nr_ope	nullable:false,blank:false,maxSize:17,scale:2
		dt_ref	nullable:false,blank:false
		dt_trm_car	nullable:false,blank:false
		nr_prs	nullable:false,blank:false,maxSize:3
		vr_tx_jrs	nullable:false,blank:false,maxSize:9,scale:4
		dt_ini_rap	nullable:true,blank:false
		sd_ini_rap	nullable:false,blank:false,maxSize:17,scale:2
		sd_vin_f01	nullable:false,blank:false,maxSize:17,scale:2
		sd_vin_f02	nullable:false,blank:false,maxSize:17,scale:2
		sd_vin_f03	nullable:false,blank:false,maxSize:17,scale:2
		sd_vin_f04	nullable:false,blank:false,maxSize:17,scale:2
		sd_vin_f05	nullable:false,blank:false,maxSize:17,scale:2
		sd_vin_f06	nullable:false,blank:false,maxSize:17,scale:2
		sd_vin_f07	nullable:false,blank:false,maxSize:17,scale:2
		sd_vin_f08	nullable:false,blank:false,maxSize:17,scale:2
		sd_vin_f09	nullable:false,blank:false,maxSize:17,scale:2
		sd_vin_f10	nullable:false,blank:false,maxSize:17,scale:2
		sd_vin_f11	nullable:false,blank:false,maxSize:17,scale:2
		sd_ven_f01	nullable:false,blank:false,maxSize:17,scale:2
		sd_ven_f02	nullable:false,blank:false,maxSize:17,scale:2
		sd_ven_f03	nullable:false,blank:false,maxSize:17,scale:2
		sd_ven_f04	nullable:false,blank:false,maxSize:17,scale:2
		sd_ven_f05	nullable:false,blank:false,maxSize:17,scale:2
		sd_ven_f06	nullable:false,blank:false,maxSize:17,scale:2
		sd_ven_f07	nullable:false,blank:false,maxSize:17,scale:2
		sd_ven_f08	nullable:false,blank:false,maxSize:17,scale:2
		sd_ven_f09	nullable:false,blank:false,maxSize:17,scale:2
		sd_ven_f10	nullable:false,blank:false,maxSize:17,scale:2
		sd_ven_f11	nullable:false,blank:false,maxSize:17,scale:2
		sd_ven_f12	nullable:false,blank:false,maxSize:17,scale:2
		vr_prj_f01	nullable:false,blank:false,maxSize:17,scale:2
		vr_prj_f02	nullable:false,blank:false,maxSize:17,scale:2
		vr_prj	nullable:false,blank:false,maxSize:17,scale:2
		vr_rec_cli	nullable:false,blank:false,maxSize:17,scale:2
		vr_eft_rap	nullable:false,blank:false,maxSize:17,scale:2
		vr_rnd_nrm	nullable:false,blank:false,maxSize:17,scale:2
		vr_prj_f03	nullable:false,blank:false,maxSize:17,scale:2
		cd_idx_cm	nullable:true,blank:false,maxSize:5
		cd_idx_jrs	nullable:true,blank:false,maxSize:5
		vr_rec_bem	nullable:true,blank:false,maxSize:17,scale:2
		vr_rec_rng	nullable:true,blank:false,maxSize:17,scale:2
		dt_pcl_ven	nullable:true,blank:false
		vr_pcl_pgo	nullable:true,blank:false,maxSize:17,scale:2
		vr_pcl_atr	nullable:true,blank:false,maxSize:17,scale:2
		vr_atr_ant	nullable:true,blank:false,maxSize:17,scale:2
		vr_rec_out	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_vin_f01	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_vin_f02	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_vin_f03	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_vin_f04	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_vin_f05	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_vin_f06	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_vin_f07	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_vin_f08	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_vin_f09	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_vin_f10	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_vin_f11	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_ven_f01	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_ven_f02	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_ven_f03	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_ven_f04	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_ven_f05	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_ven_f06	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_ven_f07	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_ven_f08	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_ven_f09	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_ven_f10	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_ven_f11	nullable:true,blank:false,maxSize:17,scale:2
		sd_rap_ven_f12	nullable:true,blank:false,maxSize:17,scale:2
		
    }
}
