package s493x039

class Saldo {
	String 	nomeOpr
	String	cd_ar_opr
	BigDecimal	cd_ag
	String	cd_ctr
	BigDecimal	nr_ope
	Date	dt_ref
	BigDecimal	cd_cli
	BigDecimal	cd_fte_rec
	BigDecimal	pc_gar_trc
	Date	dt_ini_atr
	BigDecimal	cd_sit_ctb
	Date	dt_sit_ctb
	BigDecimal	vr_ope_mn
	BigDecimal	sd_pcp_nrm
	BigDecimal	sd_pcp_atr
	BigDecimal	sd_acs_nrm
	BigDecimal	sd_acs_atr
	BigDecimal	sd_rap_nrm
	BigDecimal	sd_rap_atr
	BigDecimal	sd_prj
	BigDecimal	sd_tot_ope
	BigDecimal	sd_jrs_nrm
	BigDecimal	sd_jrs_atr
	BigDecimal	vr_dsb
	BigDecimal	cd_sis
	BigDecimal	sd_rac_nor
	BigDecimal	sd_rac_atr
	BigDecimal	cd_tp_ope
	BigDecimal	cd_sit_ope
	Date	dt_sit_ope
	Date	dh_atz
	BigDecimal	sd_rap_orn
	BigDecimal	sd_rap_ora
	BigDecimal	cd_fne_ant
	Date	dt_prx_ree
	BigDecimal	sd_pcp_cmb_lae
	BigDecimal	cd_ctb_cmb_lae
	BigDecimal	cd_ctb_exp_enc
	BigDecimal	vr_rap_jrs_nrm
	BigDecimal	cd_prg_crd
	BigDecimal	cd_ctb_nrm
	BigDecimal	cd_ctb_atr
	BigDecimal	cd_ctb_rap_nrm
	BigDecimal	cd_ctb_rap_atr
	Date 	dt_prc
	
	static mapping = {
		version false
		nomeOpr column:"nome",sqlType:"varchar",lenght:255
		cd_ar_opr	column:	"CD_AR_OPR"	,sqlType:"char"	,lenght:1
		cd_ag	column:	"CD_AG"	,sqlType:"decimal"	,precision:4
		cd_ctr	column:	"CD_CTR"	,sqlType:"char"	,lenght:10
		nr_ope	column:	"NR_OPE"	,sqlType:"decimal"	,precision:3
		dt_ref	column:	"DT_REF"	,sqlType:"datetime"
		cd_cli	column:	"CD_CLI"	,sqlType:"decimal"	,precision:7
		cd_fte_rec	column:	"CD_FTE_REC"	,sqlType:"decimal"	,precision:3
		pc_gar_trc	column:	"PC_GAR_TRC"	,sqlType:"decimal"	,precision:5 , scale:2
		dt_ini_atr	column:	"DT_INI_ATR"	,sqlType:"datetime"
		cd_sit_ctb	column:	"CD_SIT_CTB"	,sqlType:"decimal"	,precision:2
		dt_sit_ctb	column:	"DT_SIT_CTB"	,sqlType:"datetime"
		vr_ope_mn	column:	"VR_OPE_MN"	,sqlType:"decimal"	,precision:17, scale:2
		sd_pcp_nrm	column:	"SD_PCP_NRM"	,sqlType:"decimal"	,precision:17, scale:2
		sd_pcp_atr	column:	"SD_PCP_ATR"	,sqlType:"decimal"	,precision:17, scale:2
		sd_acs_nrm	column:	"SD_ACS_NRM"	,sqlType:"decimal"	,precision:17, scale:2
		sd_acs_atr	column:	"SD_ACS_ATR"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_nrm	column:	"SD_RAP_NRM"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_atr	column:	"SD_RAP_ATR"	,sqlType:"decimal"	,precision:17, scale:2
		sd_prj	column:	"SD_PRJ"	,sqlType:"decimal"	,precision:17, scale:2
		sd_tot_ope	column:	"SD_TOT_OPE"	,sqlType:"decimal"	,precision:17, scale:2
		sd_jrs_nrm	column:	"SD_JRS_NRM"	,sqlType:"decimal"	,precision:17, scale:2
		sd_jrs_atr	column:	"SD_JRS_ATR"	,sqlType:"decimal"	,precision:17, scale:2
		vr_dsb	column:	"VR_DSB"	,sqlType:"decimal"	,precision:17, scale:2
		cd_sis	column:	"CD_SIS"	,sqlType:"decimal"	,precision:4
		sd_rac_nor	column:	"SD_RAC_NOR"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rac_atr	column:	"SD_RAC_ATR"	,sqlType:"decimal"	,precision:17, scale:2
		cd_tp_ope	column:	"CD_TP_OPE"	,sqlType:"decimal"	,precision:1
		cd_sit_ope	column:	"CD_SIT_OPE"	,sqlType:"decimal"	,precision:2
		dt_sit_ope	column:	"DT_SIT_OPE"	,sqlType:"datetime"
		dh_atz	column:	"DH_ATZ"	,sqlType:"datetime"
		sd_rap_orn	column:	"SD_RAP_ORN"	,sqlType:"decimal"	,precision:17, scale:2
		sd_rap_ora	column:	"SD_RAP_ORA"	,sqlType:"decimal"	,precision:17, scale:2
		cd_fne_ant	column:	"CD_FNE_ANT"	,sqlType:"decimal"	,precision:1
		dt_prx_ree	column:	"DT_PRX_REE"	,sqlType:"datetime"
		sd_pcp_cmb_lae	column:	"SD_PCP_CMB_LAE"	,sqlType:"decimal"	,precision:17, scale:2
		cd_ctb_cmb_lae	column:	"CD_CTB_CMB_LAE"	,sqlType:"decimal"	,precision:6
		cd_ctb_exp_enc	column:	"CD_CTB_EXP_ENC"	,sqlType:"decimal"	,precision:6
		vr_rap_jrs_nrm	column:	"VR_RAP_JRS_NRM"	,sqlType:"decimal"	,precision:17, scale:2
		cd_prg_crd	column:	"CD_PRG_CRD"	,sqlType:"decimal"	,precision:4
		cd_ctb_nrm	column:	"CD_CTB_NRM"	,sqlType:"decimal"	,precision:6
		cd_ctb_atr	column:	"CD_CTB_ATR"	,sqlType:"decimal"	,precision:6
		cd_ctb_rap_nrm	column:	"CD_CTB_RAP_NRM"	,sqlType:"decimal"	,precision:6
		cd_ctb_rap_atr	column:	"CD_CTB_RAP_ATR"	,sqlType:"decimal"	,precision:6
		dt_prc column:"DT_PRC", sqlType:"datetime"
		
	}
	
    static constraints = {
		nomeOpr nullable:true , blank:false ,maxSize:255
		cd_ar_opr	nullable:false, blank:false, maxSize:1
		cd_ag	nullable:false, blank:false, maxSize:4
		cd_ctr	nullable:false, blank:false, maxSize:10
		nr_ope	nullable:false, blank:false, maxSize:3
		dt_ref	nullable:false, blank:false
		cd_cli	nullable:false, blank:false, maxSize:7
		cd_fte_rec	nullable:false, blank:false, maxSize:3
		pc_gar_trc	nullable:false, blank:false, maxSize:5 , scale:2
		dt_ini_atr	nullable:true, blank:false
		cd_sit_ctb	nullable:false, blank:false, maxSize:2
		dt_sit_ctb	nullable:true, blank:false
		vr_ope_mn	nullable:false, blank:false, maxSize:17 , scale:2
		sd_pcp_nrm	nullable:false, blank:false, maxSize:17 , scale:2
		sd_pcp_atr	nullable:false, blank:false, maxSize:17 , scale:2
		sd_acs_nrm	nullable:false, blank:false, maxSize:17 , scale:2
		sd_acs_atr	nullable:false, blank:false, maxSize:17 , scale:2
		sd_rap_nrm	nullable:false, blank:false, maxSize:17 , scale:2
		sd_rap_atr	nullable:false, blank:false, maxSize:17 , scale:2
		sd_prj	nullable:false, blank:false, maxSize:17 , scale:2
		sd_tot_ope	nullable:false, blank:false, maxSize:17 , scale:2
		sd_jrs_nrm	nullable:false, blank:false, maxSize:17 , scale:2
		sd_jrs_atr	nullable:false, blank:false, maxSize:17 , scale:2
		vr_dsb	nullable:false, blank:false, maxSize:17 , scale:2
		cd_sis	nullable:false, blank:false, maxSize:4
		sd_rac_nor	nullable:true, blank:false, maxSize:17 , scale:2
		sd_rac_atr	nullable:true, blank:false, maxSize:17 , scale:2
		cd_tp_ope	nullable:true, blank:false, maxSize:1
		cd_sit_ope	nullable:true, blank:false, maxSize:2
		dt_sit_ope	nullable:true, blank:false
		dh_atz	nullable:true, blank:false
		sd_rap_orn	nullable:true, blank:false, maxSize:17 , scale:2
		sd_rap_ora	nullable:true, blank:false, maxSize:17 , scale:2
		cd_fne_ant	nullable:true, blank:false, maxSize:1
		dt_prx_ree	nullable:true, blank:false
		sd_pcp_cmb_lae	nullable:true, blank:false, maxSize:17 , scale:2
		cd_ctb_cmb_lae	nullable:true, blank:false, maxSize:6
		cd_ctb_exp_enc	nullable:true, blank:false, maxSize:6
		vr_rap_jrs_nrm	nullable:true, blank:false, maxSize:17 , scale:2
		cd_prg_crd	nullable:true, blank:false, maxSize:4
		cd_ctb_nrm	nullable:false, blank:false, maxSize:6
		cd_ctb_atr	nullable:false, blank:false, maxSize:6
		cd_ctb_rap_nrm	nullable:true, blank:false, maxSize:6
		cd_ctb_rap_atr	nullable:true, blank:false, maxSize:6
		dt_prc	nullable:true, blank:false

		
    }
}
