package s493x039

class Cadastro {
	String	cd_ar_opr
	Double	cd_ag
	String	cd_ctr
	Double	nr_ope
	Double	cd_sis
	Double	vr_ope_um
	Double	vr_ope_mn
	Double	nr_ult_fch
	Date	dt_ctr
	Date	dt_ven_ope
	Double	cd_lim_opr
	Double	cd_pcr_ope
	Double	tx_cst_ope
	Date	dt_rcr_ope
	Double	aa_ref_bc
	Double	nr_ref_bc
	String	dv_ref_bc
	Double	pc_sub_ope
	Double	cd_moe_dsb
	String	id_ope_prf
	String	cd_vdr
	Double	cd_tit_crd
	String	mt_adm_ope
	Double	id_pen_pag
	Double	id_exp_ope
	Double	cd_sit_crd
	Double	cd_tp_pes
	String	cd_tp_rep
	Double	cd_apl_rec
	Double	cd_obj_ope
	Double	cd_mun_ope
	Double	cd_epd
	Double	id_ope_rfn
	Double	cd_tp_ast
	Double	cd_tp_rng
	Double	cd_amp_ope
	Double	cd_ope_esp
	Date	dt_cad_seb
	Double	qt_ass_bfd
	Double	id_crd_rtv
	Double	id_agc_fam
	Double	nr_pes_ase
	Date	dt_prc
	Date	dt_ult_atz
	Double	cd_cli
	Double	cd_cli_prs
	Double	cd_cli_ass
	Double	aa_prp
	Double	nr_prp
	Double	tp_gp_cli
	Date	dt_cad_ope
	Double	cd_tp_gar
	Date	dt_pri_ree
	Double	vr_tx_jrs
	Double	cd_fx_ctr
	Double	cd_ag_prp
	Double	cd_cli_prj
	Double	id_rng_ori
	Date	dt_adt
	Double	vr_crd_um
	Double	vr_crd_mn
	String	id_tot_fne
	Date	dh_atz
	Date	dt_pri_acs
	Double	cd_tp_cbt
	Double	cd_fma_crd
	Double	id_tp_pag
	Double	vr_tx_jrs_atr
	Double	vr_jrs_mor
	Double	cd_moe_atr
	Double	cd_moe_ref_atr
	Double	cd_cli_aga
	Date	dt_vig_fch
	Double	cd_tp_cta
	Double	cd_set_atv
	Double	id_sub
	Double	cd_tp_crd
	Double	cd_tp_bnf
	Double	cd_dst_rec
	Double	id_ctp_bid
	Double	id_sma
	Double	cd_fin_fnc
	Double	id_irr
	Double	cd_tp_cor
	Double	cd_fte_rec
	Double	cd_prg_crd
	Double	cd_cat_prd
	Double	id_sit_fch
	Double	cd_tp_rec
	Double	cd_moe
	Double	cd_moe_ref
	Double	id_gar
	Double	cd_ctb_nrm
	Double	cd_ctb_atr
	Double	cd_rap_nrm
	Double	cd_rap_atr
	Double	cd_rsc_fne
	Double	cd_fin_ope_ori
	Double	id_ope_alg
	Double	cd_fma_qit
	Date	dt_ult_hst
	String	id_evt_rea
	
	static mapping = {
		version false
		cd_ar_opr	column:	"CD_AR_OPR"	,sqlType:"char"	,length:1
		cd_ag	column:	"CD_AG"	,sqlType:"decimal"	,precision:4
		cd_ctr	column:	"CD_CTR"	,sqlType:"char"	,length:10
		nr_ope	column:	"NR_OPE"	,sqlType:"decimal"	,precision:3
		cd_sis	column:	"CD_SIS"	,sqlType:"decimal"	,precision:4
		vr_ope_um	column:	"VR_OPE_UM"	,sqlType:"decimal"	
		vr_ope_mn	column:	"VR_OPE_MN"	,sqlType:"decimal"	
		nr_ult_fch	column:	"NR_ULT_FCH"	,sqlType:"decimal"	,precision:3
		dt_ctr	column:	"DT_CTR"	,sqlType:"datetime"	
		dt_ven_ope	column:	"DT_VEN_OPE"	,sqlType:"datetime"	
		cd_lim_opr	column:	"CD_LIM_OPR"	,sqlType:"decimal"	,precision:2
		cd_pcr_ope	column:	"CD_PCR_OPE"	,sqlType:"decimal"	,precision:3
		tx_cst_ope	column:	"TX_CST_OPE"	,sqlType:"decimal"	,precision:5,scale:2
		dt_rcr_ope	column:	"DT_RCR_OPE"	,sqlType:"datetime"	
		aa_ref_bc	column:	"AA_REF_BC"	,sqlType:"decimal"	,precision:4
		nr_ref_bc	column:	"NR_REF_BC"	,sqlType:"decimal"	,precision:7
		dv_ref_bc	column:	"DV_REF_BC"	,sqlType:"char"	,length:1
		pc_sub_ope	column:	"PC_SUB_OPE"	,sqlType:"decimal"	,precision:2
		cd_moe_dsb	column:	"CD_MOE_DSB"	,sqlType:"decimal"	,precision:5
		id_ope_prf	column:	"ID_OPE_PRF"	,sqlType:"char"	,length:1
		cd_vdr	column:	"CD_VDR"	,sqlType:"char"	,length:5
		cd_tit_crd	column:	"CD_TIT_CRD"	,sqlType:"decimal"	,precision:2
		mt_adm_ope	column:	"MT_ADM_OPE"	,sqlType:"char"	,length:6
		id_pen_pag	column:	"ID_PEN_PAG"	,sqlType:"decimal"	,precision:1
		id_exp_ope	column:	"ID_EXP_OPE"	,sqlType:"decimal"	,precision:1
		cd_sit_crd	column:	"CD_SIT_CRD"	,sqlType:"decimal"	,precision:1
		cd_tp_pes	column:	"CD_TP_PES"	,sqlType:"decimal"	,precision:1
		cd_tp_rep	column:	"CD_TP_REP"	,sqlType:"char"	,lenght:10
		cd_apl_rec	column:	"CD_APL_REC"	,sqlType:"decimal"	,precision:2
		cd_obj_ope	column:	"CD_OBJ_OPE"	,sqlType:"decimal"	,precision:2
		cd_mun_ope	column:	"CD_MUN_OPE"	,sqlType:"decimal"	,precision:5
		cd_epd	column:	"CD_EPD"	,sqlType:"decimal"	,precision:11
		id_ope_rfn	column:	"ID_OPE_RFN"	,sqlType:"decimal"	,precision:1
		cd_tp_ast	column:	"CD_TP_AST"	,sqlType:"decimal"	,precision:1
		cd_tp_rng	column:	"CD_TP_RNG"	,sqlType:"decimal"	,precision:1
		cd_amp_ope	column:	"CD_AMP_OPE"	,sqlType:"decimal"	,precision:1
		cd_ope_esp	column:	"CD_OPE_ESP"	,sqlType:"decimal"	,precision:1
		dt_cad_seb	column:	"DT_CAD_SEB"	,sqlType:"datetime"	
		qt_ass_bfd	column:	"QT_ASS_BFD"	,sqlType:"decimal"	,precision:5
		id_crd_rtv	column:	"ID_CRD_RTV"	,sqlType:"decimal"	,precision:1
		id_agc_fam	column:	"ID_AGC_FAM"	,sqlType:"decimal"	,precision:1
		nr_pes_ase	column:	"NR_PES_ASE"	,sqlType:"decimal"	,precision:5
		dt_prc	column:	"DT_PRC"	,sqlType:"datetime"	
		dt_ult_atz	column:	"DT_ULT_ATZ"	,sqlType:"datetime"	
		cd_cli	column:	"CD_CLI"	,sqlType:"decimal"	,precision:7
		cd_cli_prs	column:	"CD_CLI_PRS"	,sqlType:"decimal"	,precision:7
		cd_cli_ass	column:	"CD_CLI_ASS"	,sqlType:"decimal"	,precision:7
		aa_prp	column:	"AA_PRP"	,sqlType:"decimal"	,precision:4
		nr_prp	column:	"NR_PRP"	,sqlType:"decimal"	,precision:7
		tp_gp_cli	column:	"TP_GP_CLI"	,sqlType:"decimal"	,precision:2
		dt_cad_ope	column:	"DT_CAD_OPE"	,sqlType:"datetime"	
		cd_tp_gar	column:	"CD_TP_GAR"	,sqlType:"decimal"	,precision:2
		dt_pri_ree	column:	"DT_PRI_REE"	,sqlType:"datetime"
		vr_tx_jrs	column:	"VR_TX_JRS"	,sqlType:"decimal"	,precision:9,scale:4
		cd_fx_ctr	column:	"CD_FX_CTR"	,sqlType:"decimal"	,precision:2
		cd_ag_prp	column:	"CD_AG_PRP"	,sqlType:"decimal"	,precision:4
		cd_cli_prj	column:	"CD_CLI_PRJ"	,sqlType:"decimal"	,precision:7
		id_rng_ori	column:	"ID_RNG_ORI"	,sqlType:"decimal"	,precision:1
		dt_adt	column:	"DT_ADT"	,sqlType:"datetime"	
		vr_crd_um	column:	"VR_CRD_UM"	,sqlType:"decimal"	
		vr_crd_mn	column:	"VR_CRD_MN"	,sqlType:"decimal"	
		id_tot_fne	column:	"ID_TOT_FNE"	,sqlType:"varchar"	,lenght:1
		dh_atz	column:	"DH_ATZ"	,sqlType:"datetime"	
		dt_pri_acs	column:	"DT_PRI_ACS"	,sqlType:"datetime"	
		cd_tp_cbt	column:	"CD_TP_CBT"	,sqlType:"decimal"	,precision:1
		cd_fma_crd	column:	"CD_FMA_CRD"	,sqlType:"decimal"	,precision:1
		id_tp_pag	column:	"ID_TP_PAG"	,sqlType:"decimal"	,precision:1
		vr_tx_jrs_atr	column:	"VR_TX_JRS_ATR"	,sqlType:"decimal"	
		vr_jrs_mor	column:	"VR_JRS_MOR"	,sqlType:"decimal"	
		cd_moe_atr	column:	"CD_MOE_ATR"	,sqlType:"decimal"	,precision:5
		cd_moe_ref_atr	column:	"CD_MOE_REF_ATR"	,sqlType:"decimal"	,precision:5
		cd_cli_aga	column:	"CD_CLI_AGA"	,sqlType:"decimal"	,precision:7
		dt_vig_fch	column:	"DT_VIG_FCH"	,sqlType:"datetime"	
		cd_tp_cta	column:	"CD_TP_CTA"	,sqlType:"decimal"	,precision:2
		cd_set_atv	column:	"CD_SET_ATV"	,sqlType:"decimal"	,precision:1
		id_sub	column:	"ID_SUB"	,sqlType:"decimal"	,precision:1
		cd_tp_crd	column:	"CD_TP_CRD"	,sqlType:"decimal"	,precision:1
		cd_tp_bnf	column:	"CD_TP_BNF"	,sqlType:"decimal"	,precision:2
		cd_dst_rec	column:	"CD_DST_REC"	,sqlType:"decimal"	,precision:2
		id_ctp_bid	column:	"ID_CTP_BID"	,sqlType:"decimal"	,precision:1
		id_sma	column:	"ID_SMA"	,sqlType:"decimal"	,precision:1
		cd_fin_fnc	column:	"CD_FIN_FNC"	,sqlType:"decimal"	,precision:2
		id_irr	column:	"ID_IRR"	,sqlType:"decimal"	,precision:1
		cd_tp_cor	column:	"CD_TP_COR"	,sqlType:"decimal"	,precision:1
		cd_fte_rec	column:	"CD_FTE_REC"	,sqlType:"decimal"	,precision:3
		cd_prg_crd	column:	"CD_PRG_CRD"	,sqlType:"decimal"	,precision:4
		cd_tp_pes	column:	"CD_TP_PES"	,sqlType:"decimal"	,precision:1
		cd_cat_prd	column:	"CD_CAT_PRD"	,sqlType:"decimal"	,precision:3
		id_sit_fch	column:	"ID_SIT_FCH"	,sqlType:"decimal"	,precision:1
		cd_tp_rec	column:	"CD_TP_REC"	,sqlType:"decimal"	,precision:2
		cd_moe	column:	"CD_MOE"	,sqlType:"decimal"	,precision:5
		cd_moe_ref	column:	"CD_MOE_REF"	,sqlType:"decimal"	,precision:5
		id_gar	column:	"ID_GAR"	,sqlType:"decimal"	,precision:1
		cd_ctb_nrm	column:	"CD_CTB_NRM"	,sqlType:"decimal"	,precision:6
		cd_ctb_atr	column:	"CD_CTB_ATR"	,sqlType:"decimal"	,precision:6
		cd_rap_nrm	column:	"CD_RAP_NRM"	,sqlType:"decimal"	,precision:6
		cd_rap_atr	column:	"CD_RAP_ATR"	,sqlType:"decimal"	,precision:6
		cd_rsc_fne	column:	"CD_RSC_FNE"	,sqlType:"decimal"	,precision:2
		cd_fin_ope_ori	column:	"CD_FIN_OPE_ORI"	,sqlType:"decimal"	,precision:2
		id_ope_alg	column:	"ID_OPE_ALG"	,sqlType:"decimal"	,precision:1
		cd_fma_qit	column:	"CD_FMA_QIT"	,sqlType:"decimal"	,precision:1
		dt_ult_hst	column:	"DT_ULT_HST"	,sqlType:"datetime"	
		id_evt_rea	column:	"ID_EVT_REA"	,sqlType:"char"	,length:1

	}
	
	
    static constraints = {
		id nullable:false, blank:false , unique:['cd_ar_opr','cd_ag','cd_ctr','nr_ope','dt_ult_atz']
		/*cd_ar_opr	nullable:false, blank:false, maxSize:1
		cd_ag	nullable:false, blank:false, maxSize:4
		cd_ctr	nullable:false, blank:false, maxSize:10
		nr_ope	nullable:false, blank:false, maxSize:3
		cd_sis	nullable:false, blank:false, maxSize:4
		vr_ope_um	nullable:false, blank:false, maxSize:17,scale:4
		vr_ope_mn	nullable:false, blank:false, maxSize:17,scale:2
		nr_ult_fch	nullable:false, blank:false, maxSize:3
		dt_ctr	nullable:false, blank:false
		dt_ven_ope	nullable:false, blank:false
		cd_lim_opr	nullable:true, blank:false, maxSize:2
		cd_pcr_ope	nullable:true, blank:false, maxSize:3
		tx_cst_ope	nullable:true, blank:false, maxSize:5,scale:2
		dt_rcr_ope	nullable:true, blank:false
		aa_ref_bc	nullable:false, blank:false, maxSize:4
		nr_ref_bc	nullable:false, blank:false, maxSize:7
		dv_ref_bc	nullable:false, blank:false, maxSize:1
		pc_sub_ope	nullable:false, blank:false, maxSize:2
		cd_moe_dsb	nullable:false, blank:false, maxSize:5
		id_ope_prf	nullable:false, blank:false, maxSize:1
		cd_vdr	nullable:true, blank:false, maxSize:5
		cd_tit_crd	nullable:false, blank:false, maxSize:2
		mt_adm_ope	nullable:false, blank:false, maxSize:6
		id_pen_pag	nullable:false, blank:false, maxSize:1
		id_exp_ope	nullable:false, blank:false, maxSize:1
		cd_sit_crd	nullable:false, blank:false, maxSize:1
		cd_tp_pes	nullable:false, blank:false, maxSize:1
		cd_tp_rep	nullable:false, blank:false, maxSize:10
		cd_apl_rec	nullable:false, blank:false, maxSize:2
		cd_obj_ope	nullable:false, blank:false, maxSize:2
		cd_mun_ope	nullable:false, blank:false, maxSize:5
		cd_epd	nullable:true, blank:false, maxSize:11
		id_ope_rfn	nullable:false, blank:false, maxSize:1
		cd_tp_ast	nullable:false, blank:false, maxSize:1
		cd_tp_rng	nullable:false, blank:false, maxSize:1
		cd_amp_ope	nullable:false, blank:false, maxSize:1
		cd_ope_esp	nullable:false, blank:false, maxSize:1
		dt_cad_seb	nullable:false, blank:false
		qt_ass_bfd	nullable:false, blank:false, maxSize:5
		id_crd_rtv	nullable:false, blank:false, maxSize:1
		id_agc_fam	nullable:false, blank:false, maxSize:1
		nr_pes_ase	nullable:false, blank:false, maxSize:5
		dt_prc	nullable:false, blank:false
		dt_ult_atz	nullable:false, blank:false
		cd_cli	nullable:false, blank:false, maxSize:7
		cd_cli_prs	nullable:true, blank:false, maxSize:7
		cd_cli_ass	nullable:true, blank:false, maxSize:7
		aa_prp	nullable:false, blank:false, maxSize:4
		nr_prp	nullable:false, blank:false, maxSize:7
		tp_gp_cli	nullable:false, blank:false, maxSize:2
		dt_cad_ope	nullable:false, blank:false
		cd_tp_gar	nullable:false, blank:false, maxSize:2
		dt_pri_ree	nullable:false, blank:false
		vr_tx_jrs	nullable:false, blank:false, maxSize:9,scale:4
		cd_fx_ctr	nullable:false, blank:false, maxSize:2
		cd_ag_prp	nullable:false, blank:false, maxSize:4
		cd_cli_prj	nullable:true, blank:false, maxSize:7
		id_rng_ori	nullable:false, blank:false, maxSize:1
		dt_adt	nullable:false, blank:false
		vr_crd_um	nullable:false, blank:false, maxSize:17,scale:4
		vr_crd_mn	nullable:false, blank:false, maxSize:17,scale:2
		id_tot_fne	nullable:false, blank:false, maxSize:1
		dh_atz	nullable:true, blank:false
		dt_pri_acs	nullable:false, blank:false
		cd_tp_cbt	nullable:false, blank:false, maxSize:1
		cd_fma_crd	nullable:true, blank:false, maxSize:1
		id_tp_pag	nullable:false, blank:false, maxSize:1
		vr_tx_jrs_atr	nullable:false, blank:false, maxSize:9,scale:4
		vr_jrs_mor	nullable:false, blank:false, maxSize:9,scale:4
		cd_moe_atr	nullable:false, blank:false, maxSize:5
		cd_moe_ref_atr	nullable:false, blank:false, maxSize:5
		cd_cli_aga	nullable:false, blank:false, maxSize:7
		dt_vig_fch	nullable:false, blank:false
		cd_tp_cta	nullable:false, blank:false, maxSize:2
		cd_set_atv	nullable:false, blank:false, maxSize:1
		id_sub	nullable:false, blank:false, maxSize:1
		cd_tp_crd	nullable:false, blank:false, maxSize:1
		cd_tp_bnf	nullable:false, blank:false, maxSize:2
		cd_dst_rec	nullable:false, blank:false, maxSize:2
		id_ctp_bid	nullable:false, blank:false, maxSize:1
		id_sma	nullable:false, blank:false, maxSize:1
		cd_fin_fnc	nullable:false, blank:false, maxSize:2
		id_irr	nullable:false, blank:false, maxSize:1
		cd_tp_cor	nullable:false, blank:false, maxSize:1
		cd_fte_rec	nullable:false, blank:false, maxSize:3
		cd_prg_crd	nullable:false, blank:false, maxSize:4
		cd_tp_pes	nullable:false, blank:false, maxSize:1
		cd_cat_prd	nullable:false, blank:false, maxSize:3
		id_sit_fch	nullable:false, blank:false, maxSize:1
		cd_tp_rec	nullable:false, blank:false, maxSize:2
		cd_moe	nullable:false, blank:false, maxSize:5
		cd_moe_ref	nullable:false, blank:false, maxSize:5
		id_gar	nullable:false, blank:false, maxSize:1
		cd_ctb_nrm	nullable:false, blank:false, maxSize:6
		cd_ctb_atr	nullable:false, blank:false, maxSize:6
		cd_rap_nrm	nullable:true, blank:false, maxSize:6
		cd_rap_atr	nullable:true, blank:false, maxSize:6
		cd_rsc_fne	nullable:true, blank:false, maxSize:2
		cd_fin_ope_ori	nullable:true, blank:false, maxSize:2
		id_ope_alg	nullable:true, blank:false, maxSize:1
		cd_fma_qit	nullable:false, blank:false, maxSize:1
		dt_ult_hst	nullable:false, blank:false
		id_evt_rea	nullable:false, blank:false, maxSize:1*/
		
    }
}
