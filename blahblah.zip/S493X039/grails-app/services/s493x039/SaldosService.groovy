package s493x039

import java.nio.file.attribute.FileTime.DaysAndNanos;

import grails.transaction.Transactional

@Transactional
class SaldosService {

    def submeterSaldo(Saldo saldoInstance) {
		def novo = new Saldo()
		novo.nomeOpr	=	saldoInstance.nomeOpr
		novo.cd_ar_opr	=	saldoInstance.cd_ar_opr
		novo.cd_ag	=	saldoInstance.cd_ag
		novo.cd_ctr	=	saldoInstance.cd_ctr
		novo.nr_ope	=	saldoInstance.nr_ope
		novo.dt_ref	=	saldoInstance.dt_ref
		novo.cd_cli	=	saldoInstance.cd_cli
		novo.cd_fte_rec	=	saldoInstance.cd_fte_rec
		novo.pc_gar_trc	=	saldoInstance.pc_gar_trc
		novo.dt_ini_atr	=	saldoInstance.dt_ini_atr
		novo.cd_sit_ctb	=	saldoInstance.cd_sit_ctb
		novo.dt_sit_ctb	=	saldoInstance.dt_sit_ctb
		novo.vr_ope_mn	=	saldoInstance.vr_ope_mn
		
		
		novo.sd_pcp_nrm	=	saldoInstance.sd_pcp_nrm
		novo.sd_pcp_atr	=	saldoInstance.sd_pcp_atr
		novo.sd_acs_nrm	=	saldoInstance.sd_acs_nrm
		novo.sd_acs_atr	=	saldoInstance.sd_acs_atr
		novo.sd_rap_nrm	=	saldoInstance.sd_rap_nrm
		novo.sd_rap_atr	=	saldoInstance.sd_rap_atr
		novo.sd_prj	=	saldoInstance.sd_prj
		novo.sd_tot_ope	=	novo.sd_pcp_nrm + novo.sd_acs_nrm
		novo.sd_jrs_nrm	=	saldoInstance.sd_jrs_nrm
		novo.sd_jrs_atr	=	saldoInstance.sd_jrs_atr
		novo.vr_dsb	=	saldoInstance.vr_dsb
		novo.cd_sis	=	saldoInstance.cd_sis
		novo.sd_rac_nor	=	saldoInstance.sd_rac_nor
		novo.sd_rac_atr	=	saldoInstance.sd_rac_atr
		novo.cd_tp_ope	=	saldoInstance.cd_tp_ope
		novo.cd_sit_ope	=	saldoInstance.cd_sit_ope
		novo.dt_sit_ope	=	saldoInstance.dt_sit_ope
		novo.dh_atz	=	saldoInstance.dh_atz
		novo.sd_rap_orn	=	saldoInstance.sd_rap_orn
		novo.sd_rap_ora	=	saldoInstance.sd_rap_ora
		novo.cd_fne_ant	=	saldoInstance.cd_fne_ant
		if(saldoInstance.dt_prx_ree)
		novo.dt_prx_ree	=	saldoInstance.dt_prx_ree
		
		
		novo.sd_pcp_cmb_lae	=	saldoInstance.sd_pcp_cmb_lae
		novo.cd_ctb_cmb_lae	=	saldoInstance.cd_ctb_cmb_lae
		novo.cd_ctb_exp_enc	=	saldoInstance.cd_ctb_exp_enc
		novo.vr_rap_jrs_nrm	=	saldoInstance.vr_rap_jrs_nrm
		novo.cd_prg_crd	=	saldoInstance.cd_prg_crd
		novo.cd_ctb_nrm	=	saldoInstance.cd_ctb_nrm
		novo.cd_ctb_atr	=	saldoInstance.cd_ctb_atr
		novo.cd_ctb_rap_nrm	=	saldoInstance.cd_ctb_rap_nrm
		novo.cd_ctb_rap_atr	=	saldoInstance.cd_ctb_rap_atr
		
		
		
		return novo
    }
	
	def submeterSaldoFaixa(Saldo saldoInstance){
		def saldoTotal = Saldo.find("SELECT s.sd_tot_ope FROM Saldo s WHERE s.dt_ref = :dtRef AND s.nome = :nome",[dtRef:dataReferencia,nome:nomeOpr])
		
	}
}
