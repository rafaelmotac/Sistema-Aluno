import s493x039.T039TFIN

import s039.T039tfin

//def copia = T039TFIN.findAll()

def original = T039tfin.findAll()

for(T039tfin elementos in original){
    def destino = new T039TFIN()
    destino.cd_fin_fnc = elementos.cdFinFnc
    destino.nm_fin_fnc = elementos.nmFinFnc
    destino.save()
}


