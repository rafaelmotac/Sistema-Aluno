// test that the calculation is fold to 13
var a = 1 + 2 * 6;

// test that it isn't replaced with 0.3333 because that is more characters
var b = 1/3;