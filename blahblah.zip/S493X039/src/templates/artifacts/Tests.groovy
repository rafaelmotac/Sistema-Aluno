@artifact.package@import grails.test.*

class @artifact.name@ extends @artifact.superclass@ {
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }

    void testSomething() {

    }
}
