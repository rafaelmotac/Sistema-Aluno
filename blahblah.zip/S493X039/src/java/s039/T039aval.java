package s039;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the T039AVAL database table.
 * 
 */
@Entity
@Table(name="T039AVAL")
@NamedQuery(name="T039aval.findAll", query="SELECT t FROM T039aval t")
public class T039aval implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private T039avalPK id;

	public T039aval() {
	}

	public T039avalPK getId() {
		return this.id;
	}

	public void setId(T039avalPK id) {
		this.id = id;
	}

}