package s039;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the T039DESE database table.
 * 
 */
@Entity
@Table(name="T039DESE")
@NamedQuery(name="T039dese.findAll", query="SELECT t FROM T039dese t")
public class T039dese implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private T039desePK id;

	@Column(name="VR_DSB")
	private BigDecimal vrDsb;

	public T039dese() {
	}

	public T039desePK getId() {
		return this.id;
	}

	public void setId(T039desePK id) {
		this.id = id;
	}

	public BigDecimal getVrDsb() {
		return this.vrDsb;
	}

	public void setVrDsb(BigDecimal vrDsb) {
		this.vrDsb = vrDsb;
	}

}