package s039;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the T039REEM database table.
 * 
 */
@Entity
@Table(name="T039REEM")
@NamedQuery(name="T039reem.findAll", query="SELECT t FROM T039reem t")
public class T039reem implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private T039reemPK id;

	@Column(name="PC_REE")
	private BigDecimal pcRee;

	@Column(name="QT_PCL")
	private BigDecimal qtPcl;

	@Column(name="VR_REE")
	private BigDecimal vrRee;

	public T039reem() {
	}

	public T039reemPK getId() {
		return this.id;
	}

	public void setId(T039reemPK id) {
		this.id = id;
	}

	public BigDecimal getPcRee() {
		return this.pcRee;
	}

	public void setPcRee(BigDecimal pcRee) {
		this.pcRee = pcRee;
	}

	public BigDecimal getQtPcl() {
		return this.qtPcl;
	}

	public void setQtPcl(BigDecimal qtPcl) {
		this.qtPcl = qtPcl;
	}

	public BigDecimal getVrRee() {
		return this.vrRee;
	}

	public void setVrRee(BigDecimal vrRee) {
		this.vrRee = vrRee;
	}

}