package s039;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the T039HFIX database table.
 * 
 */
@Entity
@Table(name="T039HFIX")
@NamedQuery(name="T039hfix.findAll", query="SELECT t FROM T039hfix t")
public class T039hfix implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private T039hfixPK id;

	@Column(name="CD_ATV", columnDefinition="decimal")
	private BigDecimal cdAtv;

	@Column(name="CD_CAT_PRD", columnDefinition="decimal")
	private BigDecimal cdCatPrd;

	@Column(name="CD_CTB_ATR", columnDefinition="decimal")
	private BigDecimal cdCtbAtr;

	@Column(name="CD_CTB_NRM", columnDefinition="decimal")
	private BigDecimal cdCtbNrm;

	@Column(name="CD_DST_REC", columnDefinition="decimal")
	private BigDecimal cdDstRec;

	@Column(name="CD_FIN_OPE_ORI", columnDefinition="decimal")
	private BigDecimal cdFinOpeOri;

	@Column(name="CD_FTE_REC", columnDefinition="decimal")
	private BigDecimal cdFteRec;

	@Column(name="CD_MOE", columnDefinition="decimal")
	private BigDecimal cdMoe;

	@Column(name="CD_MOE_REF", columnDefinition="decimal")
	private BigDecimal cdMoeRef;

	@Column(name="CD_PRG_CRD", columnDefinition="decimal")
	private BigDecimal cdPrgCrd;

	@Column(name="CD_RAP_ATR", columnDefinition="decimal")
	private BigDecimal cdRapAtr;

	@Column(name="CD_RAP_NRM", columnDefinition="decimal")
	private BigDecimal cdRapNrm;

	@Column(name="CD_RSC_FNE", columnDefinition="decimal")
	private BigDecimal cdRscFne;

	@Column(name="CD_SET_ATV", columnDefinition="decimal")
	private BigDecimal cdSetAtv;

	@Column(name="CD_SIS", columnDefinition="decimal")
	private BigDecimal cdSis;

	@Column(name="CD_TP_BNF", columnDefinition="decimal")
	private BigDecimal cdTpBnf;

	@Column(name="CD_TP_COR", columnDefinition="decimal")
	private BigDecimal cdTpCor;

	@Column(name="CD_TP_CRD", columnDefinition="decimal")
	private BigDecimal cdTpCrd;

	@Column(name="CD_TP_CTA", columnDefinition="decimal")
	private BigDecimal cdTpCta;

	@Column(name="CD_TP_PES", columnDefinition="decimal")
	private BigDecimal cdTpPes;

	@Column(name="CD_TP_REC", columnDefinition="decimal")
	private BigDecimal cdTpRec;

	@Column(name="DH_ATZ")
	private Timestamp dhAtz;

	@Column(name="DT_PRC")
	private Timestamp dtPrc;

	@Column(name="ID_CTP_BID", columnDefinition="decimal")
	private BigDecimal idCtpBid;

	@Column(name="ID_GAR", columnDefinition="decimal")
	private BigDecimal idGar;

	@Column(name="ID_IRR", columnDefinition="decimal")
	private BigDecimal idIrr;

	@Column(name="ID_OPE_ALG", columnDefinition="decimal")
	private BigDecimal idOpeAlg;

	@Column(name="ID_SIT_FCH", columnDefinition="decimal")
	private BigDecimal idSitFch;

	@Column(name="ID_SMA", columnDefinition="decimal")
	private BigDecimal idSma;

	@Column(name="ID_SUB", columnDefinition="decimal")
	private BigDecimal idSub;

	//bi-directional many-to-one association to T039tfin
	@ManyToOne
	@JoinColumn(name="CD_FIN_FNC")
	private T039tfin t039tfin;

	public T039hfix() {
	}

	public T039hfixPK getId() {
		return this.id;
	}

	public void setId(T039hfixPK id) {
		this.id = id;
	}

	public BigDecimal getCdAtv() {
		return this.cdAtv;
	}

	public void setCdAtv(BigDecimal cdAtv) {
		this.cdAtv = cdAtv;
	}

	public BigDecimal getCdCatPrd() {
		return this.cdCatPrd;
	}

	public void setCdCatPrd(BigDecimal cdCatPrd) {
		this.cdCatPrd = cdCatPrd;
	}

	public BigDecimal getCdCtbAtr() {
		return this.cdCtbAtr;
	}

	public void setCdCtbAtr(BigDecimal cdCtbAtr) {
		this.cdCtbAtr = cdCtbAtr;
	}

	public BigDecimal getCdCtbNrm() {
		return this.cdCtbNrm;
	}

	public void setCdCtbNrm(BigDecimal cdCtbNrm) {
		this.cdCtbNrm = cdCtbNrm;
	}

	public BigDecimal getCdDstRec() {
		return this.cdDstRec;
	}

	public void setCdDstRec(BigDecimal cdDstRec) {
		this.cdDstRec = cdDstRec;
	}

	public BigDecimal getCdFinOpeOri() {
		return this.cdFinOpeOri;
	}

	public void setCdFinOpeOri(BigDecimal cdFinOpeOri) {
		this.cdFinOpeOri = cdFinOpeOri;
	}

	public BigDecimal getCdFteRec() {
		return this.cdFteRec;
	}

	public void setCdFteRec(BigDecimal cdFteRec) {
		this.cdFteRec = cdFteRec;
	}

	public BigDecimal getCdMoe() {
		return this.cdMoe;
	}

	public void setCdMoe(BigDecimal cdMoe) {
		this.cdMoe = cdMoe;
	}

	public BigDecimal getCdMoeRef() {
		return this.cdMoeRef;
	}

	public void setCdMoeRef(BigDecimal cdMoeRef) {
		this.cdMoeRef = cdMoeRef;
	}

	public BigDecimal getCdPrgCrd() {
		return this.cdPrgCrd;
	}

	public void setCdPrgCrd(BigDecimal cdPrgCrd) {
		this.cdPrgCrd = cdPrgCrd;
	}

	public BigDecimal getCdRapAtr() {
		return this.cdRapAtr;
	}

	public void setCdRapAtr(BigDecimal cdRapAtr) {
		this.cdRapAtr = cdRapAtr;
	}

	public BigDecimal getCdRapNrm() {
		return this.cdRapNrm;
	}

	public void setCdRapNrm(BigDecimal cdRapNrm) {
		this.cdRapNrm = cdRapNrm;
	}

	public BigDecimal getCdRscFne() {
		return this.cdRscFne;
	}

	public void setCdRscFne(BigDecimal cdRscFne) {
		this.cdRscFne = cdRscFne;
	}

	public BigDecimal getCdSetAtv() {
		return this.cdSetAtv;
	}

	public void setCdSetAtv(BigDecimal cdSetAtv) {
		this.cdSetAtv = cdSetAtv;
	}

	public BigDecimal getCdSis() {
		return this.cdSis;
	}

	public void setCdSis(BigDecimal cdSis) {
		this.cdSis = cdSis;
	}

	public BigDecimal getCdTpBnf() {
		return this.cdTpBnf;
	}

	public void setCdTpBnf(BigDecimal cdTpBnf) {
		this.cdTpBnf = cdTpBnf;
	}

	public BigDecimal getCdTpCor() {
		return this.cdTpCor;
	}

	public void setCdTpCor(BigDecimal cdTpCor) {
		this.cdTpCor = cdTpCor;
	}

	public BigDecimal getCdTpCrd() {
		return this.cdTpCrd;
	}

	public void setCdTpCrd(BigDecimal cdTpCrd) {
		this.cdTpCrd = cdTpCrd;
	}

	public BigDecimal getCdTpCta() {
		return this.cdTpCta;
	}

	public void setCdTpCta(BigDecimal cdTpCta) {
		this.cdTpCta = cdTpCta;
	}

	public BigDecimal getCdTpPes() {
		return this.cdTpPes;
	}

	public void setCdTpPes(BigDecimal cdTpPes) {
		this.cdTpPes = cdTpPes;
	}

	public BigDecimal getCdTpRec() {
		return this.cdTpRec;
	}

	public void setCdTpRec(BigDecimal cdTpRec) {
		this.cdTpRec = cdTpRec;
	}

	public Timestamp getDhAtz() {
		return this.dhAtz;
	}

	public void setDhAtz(Timestamp dhAtz) {
		this.dhAtz = dhAtz;
	}

	public Timestamp getDtPrc() {
		return this.dtPrc;
	}

	public void setDtPrc(Timestamp dtPrc) {
		this.dtPrc = dtPrc;
	}

	public BigDecimal getIdCtpBid() {
		return this.idCtpBid;
	}

	public void setIdCtpBid(BigDecimal idCtpBid) {
		this.idCtpBid = idCtpBid;
	}

	public BigDecimal getIdGar() {
		return this.idGar;
	}

	public void setIdGar(BigDecimal idGar) {
		this.idGar = idGar;
	}

	public BigDecimal getIdIrr() {
		return this.idIrr;
	}

	public void setIdIrr(BigDecimal idIrr) {
		this.idIrr = idIrr;
	}

	public BigDecimal getIdOpeAlg() {
		return this.idOpeAlg;
	}

	public void setIdOpeAlg(BigDecimal idOpeAlg) {
		this.idOpeAlg = idOpeAlg;
	}

	public BigDecimal getIdSitFch() {
		return this.idSitFch;
	}

	public void setIdSitFch(BigDecimal idSitFch) {
		this.idSitFch = idSitFch;
	}

	public BigDecimal getIdSma() {
		return this.idSma;
	}

	public void setIdSma(BigDecimal idSma) {
		this.idSma = idSma;
	}

	public BigDecimal getIdSub() {
		return this.idSub;
	}

	public void setIdSub(BigDecimal idSub) {
		this.idSub = idSub;
	}

	public T039tfin getT039tfin() {
		return this.t039tfin;
	}

	public void setT039tfin(T039tfin t039tfin) {
		this.t039tfin = t039tfin;
	}

}