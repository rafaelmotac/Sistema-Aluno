package s039;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the T039FIXA database table.
 * 
 */
@Entity
@Table(name="T039FIXA")
@NamedQuery(name="T039fixa.findAll", query="SELECT t FROM T039fixa t")
public class T039fixa implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private T039fixaPK id;

	@Column(name="CD_FMA_QIT")
	private BigDecimal cdFmaQit;

	@Column(name="DH_ATZ")
	private Timestamp dhAtz;

	@Column(name="DT_ULT_ATZ")
	private Timestamp dtUltAtz;

	@Column(name="DT_ULT_HST")
	private Timestamp dtUltHst;

	@Column(name="ID_EVT_REA")
	private String idEvtRea;

	public T039fixa() {
	}

	public T039fixaPK getId() {
		return this.id;
	}

	public void setId(T039fixaPK id) {
		this.id = id;
	}

	public BigDecimal getCdFmaQit() {
		return this.cdFmaQit;
	}

	public void setCdFmaQit(BigDecimal cdFmaQit) {
		this.cdFmaQit = cdFmaQit;
	}

	public Timestamp getDhAtz() {
		return this.dhAtz;
	}

	public void setDhAtz(Timestamp dhAtz) {
		this.dhAtz = dhAtz;
	}

	public Timestamp getDtUltAtz() {
		return this.dtUltAtz;
	}

	public void setDtUltAtz(Timestamp dtUltAtz) {
		this.dtUltAtz = dtUltAtz;
	}

	public Timestamp getDtUltHst() {
		return this.dtUltHst;
	}

	public void setDtUltHst(Timestamp dtUltHst) {
		this.dtUltHst = dtUltHst;
	}

	public String getIdEvtRea() {
		return this.idEvtRea;
	}

	public void setIdEvtRea(String idEvtRea) {
		this.idEvtRea = idEvtRea;
	}

}