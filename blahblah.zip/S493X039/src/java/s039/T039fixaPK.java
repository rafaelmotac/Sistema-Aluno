package s039;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the T039FIXA database table.
 * 
 */
@Embeddable
public class T039fixaPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="CD_AR_OPR")
	private String cdArOpr;

	@Column(name="CD_AG")
	private long cdAg;

	@Column(name="CD_CTR")
	private String cdCtr;

	@Column(name="NR_OPE")
	private long nrOpe;

	public T039fixaPK() {
	}
	public String getCdArOpr() {
		return this.cdArOpr;
	}
	public void setCdArOpr(String cdArOpr) {
		this.cdArOpr = cdArOpr;
	}
	public long getCdAg() {
		return this.cdAg;
	}
	public void setCdAg(long cdAg) {
		this.cdAg = cdAg;
	}
	public String getCdCtr() {
		return this.cdCtr;
	}
	public void setCdCtr(String cdCtr) {
		this.cdCtr = cdCtr;
	}
	public long getNrOpe() {
		return this.nrOpe;
	}
	public void setNrOpe(long nrOpe) {
		this.nrOpe = nrOpe;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof T039fixaPK)) {
			return false;
		}
		T039fixaPK castOther = (T039fixaPK)other;
		return 
			this.cdArOpr.equals(castOther.cdArOpr)
			&& (this.cdAg == castOther.cdAg)
			&& this.cdCtr.equals(castOther.cdCtr)
			&& (this.nrOpe == castOther.nrOpe);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.cdArOpr.hashCode();
		hash = hash * prime + ((int) (this.cdAg ^ (this.cdAg >>> 32)));
		hash = hash * prime + this.cdCtr.hashCode();
		hash = hash * prime + ((int) (this.nrOpe ^ (this.nrOpe >>> 32)));
		
		return hash;
	}
}