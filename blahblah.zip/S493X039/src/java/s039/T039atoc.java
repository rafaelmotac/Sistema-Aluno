package s039;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the T039ATOC database table.
 * 
 */
@Entity
@Table(name="T039ATOC")
@NamedQuery(name="T039atoc.findAll", query="SELECT t FROM T039atoc t")
public class T039atoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private T039atocPK id;

	@Column(name="CD_SEC")
	private String cdSec;

	@Column(name="FT_ATV_ECN")
	private BigDecimal ftAtvEcn;

	@Column(name="VR_ATV_ECN")
	private BigDecimal vrAtvEcn;

	@Column(name="VS_CL")
	private BigDecimal vsCl;

	public T039atoc() {
	}

	public T039atocPK getId() {
		return this.id;
	}

	public void setId(T039atocPK id) {
		this.id = id;
	}

	public String getCdSec() {
		return this.cdSec;
	}

	public void setCdSec(String cdSec) {
		this.cdSec = cdSec;
	}

	public BigDecimal getFtAtvEcn() {
		return this.ftAtvEcn;
	}

	public void setFtAtvEcn(BigDecimal ftAtvEcn) {
		this.ftAtvEcn = ftAtvEcn;
	}

	public BigDecimal getVrAtvEcn() {
		return this.vrAtvEcn;
	}

	public void setVrAtvEcn(BigDecimal vrAtvEcn) {
		this.vrAtvEcn = vrAtvEcn;
	}

	public BigDecimal getVsCl() {
		return this.vsCl;
	}

	public void setVsCl(BigDecimal vsCl) {
		this.vsCl = vsCl;
	}

}