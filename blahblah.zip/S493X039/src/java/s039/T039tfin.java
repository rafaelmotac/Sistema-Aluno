package s039;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the T039TFIN database table.
 * 
 */
@Entity
@Table(name="T039TFIN")
@NamedQuery(name="T039tfin.findAll", query="SELECT t FROM T039tfin t")
public class T039tfin implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CD_FIN_FNC", columnDefinition="decimal", precision=3)
	private BigDecimal cdFinFnc;

	@Column(name="NM_FIN_FNC", columnDefinition="char", length=30)
	private String nmFinFnc;

	//bi-directional many-to-one association to T039hfix
	@OneToMany(mappedBy="t039tfin")
	private List<T039hfix> t039hfixs;

	public T039tfin() {
	}

	public BigDecimal getCdFinFnc() {
		return this.cdFinFnc;
	}

	public void setCdFinFnc(BigDecimal cdFinFnc) {
		this.cdFinFnc = cdFinFnc;
	}

	public String getNmFinFnc() {
		return this.nmFinFnc;
	}

	public void setNmFinFnc(String nmFinFnc) {
		this.nmFinFnc = nmFinFnc;
	}

	public List<T039hfix> getT039hfixs() {
		return this.t039hfixs;
	}

	public void setT039hfixs(List<T039hfix> t039hfixs) {
		this.t039hfixs = t039hfixs;
	}

	public T039hfix addT039hfix(T039hfix t039hfix) {
		getT039hfixs().add(t039hfix);
		t039hfix.setT039tfin(this);

		return t039hfix;
	}

	public T039hfix removeT039hfix(T039hfix t039hfix) {
		getT039hfixs().remove(t039hfix);
		t039hfix.setT039tfin(null);

		return t039hfix;
	}

}