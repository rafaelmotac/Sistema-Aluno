package s039;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the T039OPRA database table.
 * 
 */
@Entity
@Table(name="T039OPRA")
@NamedQuery(name="T039opra.findAll", query="SELECT t FROM T039opra t")
public class T039opra implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private T039opraPK id;

	@Column(name="AA_PRP")
	private BigDecimal aaPrp;

	@Column(name="AA_REF_BC")
	private BigDecimal aaRefBc;

	@Column(name="CD_AG_PRP")
	private BigDecimal cdAgPrp;

	@Column(name="CD_AMP_OPE")
	private BigDecimal cdAmpOpe;

	@Column(name="CD_APL_REC")
	private BigDecimal cdAplRec;

	@Column(name="CD_CLI")
	private BigDecimal cdCli;

	@Column(name="CD_CLI_AGA")
	private BigDecimal cdCliAga;

	@Column(name="CD_CLI_ASS")
	private BigDecimal cdCliAss;

	@Column(name="CD_CLI_PRJ")
	private BigDecimal cdCliPrj;

	@Column(name="CD_CLI_PRS")
	private BigDecimal cdCliPrs;

	@Column(name="CD_EPD")
	private BigDecimal cdEpd;

	@Column(name="CD_FMA_CRD")
	private BigDecimal cdFmaCrd;

	@Column(name="CD_FX_CTR")
	private BigDecimal cdFxCtr;

	@Column(name="CD_LIM_OPR")
	private BigDecimal cdLimOpr;

	@Column(name="CD_MOE_ATR")
	private BigDecimal cdMoeAtr;

	@Column(name="CD_MOE_DSB")
	private BigDecimal cdMoeDsb;

	@Column(name="CD_MOE_REF_ATR")
	private BigDecimal cdMoeRefAtr;

	@Column(name="CD_MUN_OPE")
	private BigDecimal cdMunOpe;

	@Column(name="CD_OBJ_OPE")
	private BigDecimal cdObjOpe;

	@Column(name="CD_OPE_ESP")
	private BigDecimal cdOpeEsp;

	@Column(name="CD_PCR_OPE")
	private BigDecimal cdPcrOpe;

	@Column(name="CD_PR_JRS")
	private String cdPrJrs;

	@Column(name="CD_PR_JRS_ATR")
	private String cdPrJrsAtr;

	@Column(name="CD_PR_MOR")
	private String cdPrMor;

	@Column(name="CD_SIS")
	private BigDecimal cdSis;

	@Column(name="CD_SIT_CRD")
	private BigDecimal cdSitCrd;

	@Column(name="CD_TIT_CRD")
	private BigDecimal cdTitCrd;

	@Column(name="CD_TP_AST")
	private BigDecimal cdTpAst;

	@Column(name="CD_TP_CBT")
	private BigDecimal cdTpCbt;

	@Column(name="CD_TP_GAR")
	private BigDecimal cdTpGar;

	@Column(name="CD_TP_PES")
	private BigDecimal cdTpPes;

	@Column(name="CD_TP_REP")
	private String cdTpRep;

	@Column(name="CD_TP_RNG")
	private BigDecimal cdTpRng;

	@Column(name="CD_VDR")
	private String cdVdr;

	@Column(name="DH_ATZ")
	private Timestamp dhAtz;

	@Column(name="DT_ADT")
	private Timestamp dtAdt;

	@Column(name="DT_CAD_OPE")
	private Timestamp dtCadOpe;

	@Column(name="DT_CAD_SEB")
	private Timestamp dtCadSeb;

	@Column(name="DT_CTR")
	private Timestamp dtCtr;

	@Column(name="DT_PRC")
	private Timestamp dtPrc;

	@Column(name="DT_PRI_ACS")
	private Timestamp dtPriAcs;

	@Column(name="DT_PRI_REE")
	private Timestamp dtPriRee;

	@Column(name="DT_RCR_OPE")
	private Timestamp dtRcrOpe;

	@Column(name="DT_ULT_ATZ")
	private Timestamp dtUltAtz;

	@Column(name="DT_VEN_OPE")
	private Timestamp dtVenOpe;

	@Column(name="DV_REF_BC")
	private String dvRefBc;

	@Column(name="ID_AGC_FAM")
	private BigDecimal idAgcFam;

	@Column(name="ID_CRD_RTV")
	private BigDecimal idCrdRtv;

	@Column(name="ID_EXP_OPE")
	private BigDecimal idExpOpe;

	@Column(name="ID_IVT")
	private String idIvt;

	@Column(name="ID_OPE_PRF")
	private String idOpePrf;

	@Column(name="ID_OPE_RFN")
	private BigDecimal idOpeRfn;

	@Column(name="ID_OPE_STR")
	private BigDecimal idOpeStr;

	@Column(name="ID_PEN_PAG")
	private BigDecimal idPenPag;

	@Column(name="ID_RNG_ORI")
	private BigDecimal idRngOri;

	@Column(name="ID_TOT_FNE")
	private String idTotFne;

	@Column(name="ID_TP_PAG")
	private BigDecimal idTpPag;

	@Column(name="MT_ADM_OPE")
	private String mtAdmOpe;

	@Column(name="NR_OPE_AGA")
	private String nrOpeAga;

	@Column(name="NR_PES_ASE")
	private BigDecimal nrPesAse;

	@Column(name="NR_PRP")
	private BigDecimal nrPrp;

	@Column(name="NR_PRP_AGA")
	private String nrPrpAga;

	@Column(name="NR_REF_BC")
	private BigDecimal nrRefBc;

	@Column(name="NR_REF_BC_ORI")
	private String nrRefBcOri;

	@Column(name="NR_ULT_FCH")
	private BigDecimal nrUltFch;

	@Column(name="PC_SUB_OPE")
	private BigDecimal pcSubOpe;

	@Column(name="QT_ASS_BFD")
	private BigDecimal qtAssBfd;

	@Column(name="TP_GP_CLI")
	private BigDecimal tpGpCli;

	@Column(name="TX_CST_OPE")
	private BigDecimal txCstOpe;

	@Column(name="VR_CRD_MN")
	private BigDecimal vrCrdMn;

	@Column(name="VR_CRD_UM")
	private BigDecimal vrCrdUm;

	@Column(name="VR_JRS_MOR")
	private BigDecimal vrJrsMor;

	@Column(name="VR_OPE_MN")
	private BigDecimal vrOpeMn;

	@Column(name="VR_OPE_UM")
	private BigDecimal vrOpeUm;

	@Column(name="VR_TAC")
	private BigDecimal vrTac;

	@Column(name="VR_TX_JRS")
	private BigDecimal vrTxJrs;

	@Column(name="VR_TX_JRS_ATR")
	private BigDecimal vrTxJrsAtr;

	public T039opra() {
	}

	public T039opraPK getId() {
		return this.id;
	}

	public void setId(T039opraPK id) {
		this.id = id;
	}

	public BigDecimal getAaPrp() {
		return this.aaPrp;
	}

	public void setAaPrp(BigDecimal aaPrp) {
		this.aaPrp = aaPrp;
	}

	public BigDecimal getAaRefBc() {
		return this.aaRefBc;
	}

	public void setAaRefBc(BigDecimal aaRefBc) {
		this.aaRefBc = aaRefBc;
	}

	public BigDecimal getCdAgPrp() {
		return this.cdAgPrp;
	}

	public void setCdAgPrp(BigDecimal cdAgPrp) {
		this.cdAgPrp = cdAgPrp;
	}

	public BigDecimal getCdAmpOpe() {
		return this.cdAmpOpe;
	}

	public void setCdAmpOpe(BigDecimal cdAmpOpe) {
		this.cdAmpOpe = cdAmpOpe;
	}

	public BigDecimal getCdAplRec() {
		return this.cdAplRec;
	}

	public void setCdAplRec(BigDecimal cdAplRec) {
		this.cdAplRec = cdAplRec;
	}

	public BigDecimal getCdCli() {
		return this.cdCli;
	}

	public void setCdCli(BigDecimal cdCli) {
		this.cdCli = cdCli;
	}

	public BigDecimal getCdCliAga() {
		return this.cdCliAga;
	}

	public void setCdCliAga(BigDecimal cdCliAga) {
		this.cdCliAga = cdCliAga;
	}

	public BigDecimal getCdCliAss() {
		return this.cdCliAss;
	}

	public void setCdCliAss(BigDecimal cdCliAss) {
		this.cdCliAss = cdCliAss;
	}

	public BigDecimal getCdCliPrj() {
		return this.cdCliPrj;
	}

	public void setCdCliPrj(BigDecimal cdCliPrj) {
		this.cdCliPrj = cdCliPrj;
	}

	public BigDecimal getCdCliPrs() {
		return this.cdCliPrs;
	}

	public void setCdCliPrs(BigDecimal cdCliPrs) {
		this.cdCliPrs = cdCliPrs;
	}

	public BigDecimal getCdEpd() {
		return this.cdEpd;
	}

	public void setCdEpd(BigDecimal cdEpd) {
		this.cdEpd = cdEpd;
	}

	public BigDecimal getCdFmaCrd() {
		return this.cdFmaCrd;
	}

	public void setCdFmaCrd(BigDecimal cdFmaCrd) {
		this.cdFmaCrd = cdFmaCrd;
	}

	public BigDecimal getCdFxCtr() {
		return this.cdFxCtr;
	}

	public void setCdFxCtr(BigDecimal cdFxCtr) {
		this.cdFxCtr = cdFxCtr;
	}

	public BigDecimal getCdLimOpr() {
		return this.cdLimOpr;
	}

	public void setCdLimOpr(BigDecimal cdLimOpr) {
		this.cdLimOpr = cdLimOpr;
	}

	public BigDecimal getCdMoeAtr() {
		return this.cdMoeAtr;
	}

	public void setCdMoeAtr(BigDecimal cdMoeAtr) {
		this.cdMoeAtr = cdMoeAtr;
	}

	public BigDecimal getCdMoeDsb() {
		return this.cdMoeDsb;
	}

	public void setCdMoeDsb(BigDecimal cdMoeDsb) {
		this.cdMoeDsb = cdMoeDsb;
	}

	public BigDecimal getCdMoeRefAtr() {
		return this.cdMoeRefAtr;
	}

	public void setCdMoeRefAtr(BigDecimal cdMoeRefAtr) {
		this.cdMoeRefAtr = cdMoeRefAtr;
	}

	public BigDecimal getCdMunOpe() {
		return this.cdMunOpe;
	}

	public void setCdMunOpe(BigDecimal cdMunOpe) {
		this.cdMunOpe = cdMunOpe;
	}

	public BigDecimal getCdObjOpe() {
		return this.cdObjOpe;
	}

	public void setCdObjOpe(BigDecimal cdObjOpe) {
		this.cdObjOpe = cdObjOpe;
	}

	public BigDecimal getCdOpeEsp() {
		return this.cdOpeEsp;
	}

	public void setCdOpeEsp(BigDecimal cdOpeEsp) {
		this.cdOpeEsp = cdOpeEsp;
	}

	public BigDecimal getCdPcrOpe() {
		return this.cdPcrOpe;
	}

	public void setCdPcrOpe(BigDecimal cdPcrOpe) {
		this.cdPcrOpe = cdPcrOpe;
	}

	public String getCdPrJrs() {
		return this.cdPrJrs;
	}

	public void setCdPrJrs(String cdPrJrs) {
		this.cdPrJrs = cdPrJrs;
	}

	public String getCdPrJrsAtr() {
		return this.cdPrJrsAtr;
	}

	public void setCdPrJrsAtr(String cdPrJrsAtr) {
		this.cdPrJrsAtr = cdPrJrsAtr;
	}

	public String getCdPrMor() {
		return this.cdPrMor;
	}

	public void setCdPrMor(String cdPrMor) {
		this.cdPrMor = cdPrMor;
	}

	public BigDecimal getCdSis() {
		return this.cdSis;
	}

	public void setCdSis(BigDecimal cdSis) {
		this.cdSis = cdSis;
	}

	public BigDecimal getCdSitCrd() {
		return this.cdSitCrd;
	}

	public void setCdSitCrd(BigDecimal cdSitCrd) {
		this.cdSitCrd = cdSitCrd;
	}

	public BigDecimal getCdTitCrd() {
		return this.cdTitCrd;
	}

	public void setCdTitCrd(BigDecimal cdTitCrd) {
		this.cdTitCrd = cdTitCrd;
	}

	public BigDecimal getCdTpAst() {
		return this.cdTpAst;
	}

	public void setCdTpAst(BigDecimal cdTpAst) {
		this.cdTpAst = cdTpAst;
	}

	public BigDecimal getCdTpCbt() {
		return this.cdTpCbt;
	}

	public void setCdTpCbt(BigDecimal cdTpCbt) {
		this.cdTpCbt = cdTpCbt;
	}

	public BigDecimal getCdTpGar() {
		return this.cdTpGar;
	}

	public void setCdTpGar(BigDecimal cdTpGar) {
		this.cdTpGar = cdTpGar;
	}

	public BigDecimal getCdTpPes() {
		return this.cdTpPes;
	}

	public void setCdTpPes(BigDecimal cdTpPes) {
		this.cdTpPes = cdTpPes;
	}

	public String getCdTpRep() {
		return this.cdTpRep;
	}

	public void setCdTpRep(String cdTpRep) {
		this.cdTpRep = cdTpRep;
	}

	public BigDecimal getCdTpRng() {
		return this.cdTpRng;
	}

	public void setCdTpRng(BigDecimal cdTpRng) {
		this.cdTpRng = cdTpRng;
	}

	public String getCdVdr() {
		return this.cdVdr;
	}

	public void setCdVdr(String cdVdr) {
		this.cdVdr = cdVdr;
	}

	public Timestamp getDhAtz() {
		return this.dhAtz;
	}

	public void setDhAtz(Timestamp dhAtz) {
		this.dhAtz = dhAtz;
	}

	public Timestamp getDtAdt() {
		return this.dtAdt;
	}

	public void setDtAdt(Timestamp dtAdt) {
		this.dtAdt = dtAdt;
	}

	public Timestamp getDtCadOpe() {
		return this.dtCadOpe;
	}

	public void setDtCadOpe(Timestamp dtCadOpe) {
		this.dtCadOpe = dtCadOpe;
	}

	public Timestamp getDtCadSeb() {
		return this.dtCadSeb;
	}

	public void setDtCadSeb(Timestamp dtCadSeb) {
		this.dtCadSeb = dtCadSeb;
	}

	public Timestamp getDtCtr() {
		return this.dtCtr;
	}

	public void setDtCtr(Timestamp dtCtr) {
		this.dtCtr = dtCtr;
	}

	public Timestamp getDtPrc() {
		return this.dtPrc;
	}

	public void setDtPrc(Timestamp dtPrc) {
		this.dtPrc = dtPrc;
	}

	public Timestamp getDtPriAcs() {
		return this.dtPriAcs;
	}

	public void setDtPriAcs(Timestamp dtPriAcs) {
		this.dtPriAcs = dtPriAcs;
	}

	public Timestamp getDtPriRee() {
		return this.dtPriRee;
	}

	public void setDtPriRee(Timestamp dtPriRee) {
		this.dtPriRee = dtPriRee;
	}

	public Timestamp getDtRcrOpe() {
		return this.dtRcrOpe;
	}

	public void setDtRcrOpe(Timestamp dtRcrOpe) {
		this.dtRcrOpe = dtRcrOpe;
	}

	public Timestamp getDtUltAtz() {
		return this.dtUltAtz;
	}

	public void setDtUltAtz(Timestamp dtUltAtz) {
		this.dtUltAtz = dtUltAtz;
	}

	public Timestamp getDtVenOpe() {
		return this.dtVenOpe;
	}

	public void setDtVenOpe(Timestamp dtVenOpe) {
		this.dtVenOpe = dtVenOpe;
	}

	public String getDvRefBc() {
		return this.dvRefBc;
	}

	public void setDvRefBc(String dvRefBc) {
		this.dvRefBc = dvRefBc;
	}

	public BigDecimal getIdAgcFam() {
		return this.idAgcFam;
	}

	public void setIdAgcFam(BigDecimal idAgcFam) {
		this.idAgcFam = idAgcFam;
	}

	public BigDecimal getIdCrdRtv() {
		return this.idCrdRtv;
	}

	public void setIdCrdRtv(BigDecimal idCrdRtv) {
		this.idCrdRtv = idCrdRtv;
	}

	public BigDecimal getIdExpOpe() {
		return this.idExpOpe;
	}

	public void setIdExpOpe(BigDecimal idExpOpe) {
		this.idExpOpe = idExpOpe;
	}

	public String getIdIvt() {
		return this.idIvt;
	}

	public void setIdIvt(String idIvt) {
		this.idIvt = idIvt;
	}

	public String getIdOpePrf() {
		return this.idOpePrf;
	}

	public void setIdOpePrf(String idOpePrf) {
		this.idOpePrf = idOpePrf;
	}

	public BigDecimal getIdOpeRfn() {
		return this.idOpeRfn;
	}

	public void setIdOpeRfn(BigDecimal idOpeRfn) {
		this.idOpeRfn = idOpeRfn;
	}

	public BigDecimal getIdOpeStr() {
		return this.idOpeStr;
	}

	public void setIdOpeStr(BigDecimal idOpeStr) {
		this.idOpeStr = idOpeStr;
	}

	public BigDecimal getIdPenPag() {
		return this.idPenPag;
	}

	public void setIdPenPag(BigDecimal idPenPag) {
		this.idPenPag = idPenPag;
	}

	public BigDecimal getIdRngOri() {
		return this.idRngOri;
	}

	public void setIdRngOri(BigDecimal idRngOri) {
		this.idRngOri = idRngOri;
	}

	public String getIdTotFne() {
		return this.idTotFne;
	}

	public void setIdTotFne(String idTotFne) {
		this.idTotFne = idTotFne;
	}

	public BigDecimal getIdTpPag() {
		return this.idTpPag;
	}

	public void setIdTpPag(BigDecimal idTpPag) {
		this.idTpPag = idTpPag;
	}

	public String getMtAdmOpe() {
		return this.mtAdmOpe;
	}

	public void setMtAdmOpe(String mtAdmOpe) {
		this.mtAdmOpe = mtAdmOpe;
	}

	public String getNrOpeAga() {
		return this.nrOpeAga;
	}

	public void setNrOpeAga(String nrOpeAga) {
		this.nrOpeAga = nrOpeAga;
	}

	public BigDecimal getNrPesAse() {
		return this.nrPesAse;
	}

	public void setNrPesAse(BigDecimal nrPesAse) {
		this.nrPesAse = nrPesAse;
	}

	public BigDecimal getNrPrp() {
		return this.nrPrp;
	}

	public void setNrPrp(BigDecimal nrPrp) {
		this.nrPrp = nrPrp;
	}

	public String getNrPrpAga() {
		return this.nrPrpAga;
	}

	public void setNrPrpAga(String nrPrpAga) {
		this.nrPrpAga = nrPrpAga;
	}

	public BigDecimal getNrRefBc() {
		return this.nrRefBc;
	}

	public void setNrRefBc(BigDecimal nrRefBc) {
		this.nrRefBc = nrRefBc;
	}

	public String getNrRefBcOri() {
		return this.nrRefBcOri;
	}

	public void setNrRefBcOri(String nrRefBcOri) {
		this.nrRefBcOri = nrRefBcOri;
	}

	public BigDecimal getNrUltFch() {
		return this.nrUltFch;
	}

	public void setNrUltFch(BigDecimal nrUltFch) {
		this.nrUltFch = nrUltFch;
	}

	public BigDecimal getPcSubOpe() {
		return this.pcSubOpe;
	}

	public void setPcSubOpe(BigDecimal pcSubOpe) {
		this.pcSubOpe = pcSubOpe;
	}

	public BigDecimal getQtAssBfd() {
		return this.qtAssBfd;
	}

	public void setQtAssBfd(BigDecimal qtAssBfd) {
		this.qtAssBfd = qtAssBfd;
	}

	public BigDecimal getTpGpCli() {
		return this.tpGpCli;
	}

	public void setTpGpCli(BigDecimal tpGpCli) {
		this.tpGpCli = tpGpCli;
	}

	public BigDecimal getTxCstOpe() {
		return this.txCstOpe;
	}

	public void setTxCstOpe(BigDecimal txCstOpe) {
		this.txCstOpe = txCstOpe;
	}

	public BigDecimal getVrCrdMn() {
		return this.vrCrdMn;
	}

	public void setVrCrdMn(BigDecimal vrCrdMn) {
		this.vrCrdMn = vrCrdMn;
	}

	public BigDecimal getVrCrdUm() {
		return this.vrCrdUm;
	}

	public void setVrCrdUm(BigDecimal vrCrdUm) {
		this.vrCrdUm = vrCrdUm;
	}

	public BigDecimal getVrJrsMor() {
		return this.vrJrsMor;
	}

	public void setVrJrsMor(BigDecimal vrJrsMor) {
		this.vrJrsMor = vrJrsMor;
	}

	public BigDecimal getVrOpeMn() {
		return this.vrOpeMn;
	}

	public void setVrOpeMn(BigDecimal vrOpeMn) {
		this.vrOpeMn = vrOpeMn;
	}

	public BigDecimal getVrOpeUm() {
		return this.vrOpeUm;
	}

	public void setVrOpeUm(BigDecimal vrOpeUm) {
		this.vrOpeUm = vrOpeUm;
	}

	public BigDecimal getVrTac() {
		return this.vrTac;
	}

	public void setVrTac(BigDecimal vrTac) {
		this.vrTac = vrTac;
	}

	public BigDecimal getVrTxJrs() {
		return this.vrTxJrs;
	}

	public void setVrTxJrs(BigDecimal vrTxJrs) {
		this.vrTxJrs = vrTxJrs;
	}

	public BigDecimal getVrTxJrsAtr() {
		return this.vrTxJrsAtr;
	}

	public void setVrTxJrsAtr(BigDecimal vrTxJrsAtr) {
		this.vrTxJrsAtr = vrTxJrsAtr;
	}

}