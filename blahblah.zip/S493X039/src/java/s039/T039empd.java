package s039;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the T039EMPD database table.
 * 
 */
@Entity
@Table(name="T039EMPD")
@NamedQuery(name="T039empd.findAll", query="SELECT t FROM T039empd t")
public class T039empd implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private T039empdPK id;

	@Column(name="DT_REF")
	private Timestamp dtRef;

	@Column(name="NM_UND_FNC")
	private String nmUndFnc;

	@Column(name="PR_SFR")
	private String prSfr;

	@Column(name="QT_AR_FNC")
	private BigDecimal qtArFnc;

	@Column(name="QT_FNC")
	private BigDecimal qtFnc;

	@Column(name="QT_PRV_PRD")
	private BigDecimal qtPrvPrd;

	@Column(name="TX_PAG")
	private BigDecimal txPag;

	@Column(name="VR_DSB")
	private BigDecimal vrDsb;

	@Column(name="VR_FT_EMP")
	private BigDecimal vrFtEmp;

	@Column(name="VR_REC_BCO")
	private BigDecimal vrRecBco;

	@Column(name="VR_REC_PRP")
	private BigDecimal vrRecPrp;

	public T039empd() {
	}

	public T039empdPK getId() {
		return this.id;
	}

	public void setId(T039empdPK id) {
		this.id = id;
	}

	public Timestamp getDtRef() {
		return this.dtRef;
	}

	public void setDtRef(Timestamp dtRef) {
		this.dtRef = dtRef;
	}

	public String getNmUndFnc() {
		return this.nmUndFnc;
	}

	public void setNmUndFnc(String nmUndFnc) {
		this.nmUndFnc = nmUndFnc;
	}

	public String getPrSfr() {
		return this.prSfr;
	}

	public void setPrSfr(String prSfr) {
		this.prSfr = prSfr;
	}

	public BigDecimal getQtArFnc() {
		return this.qtArFnc;
	}

	public void setQtArFnc(BigDecimal qtArFnc) {
		this.qtArFnc = qtArFnc;
	}

	public BigDecimal getQtFnc() {
		return this.qtFnc;
	}

	public void setQtFnc(BigDecimal qtFnc) {
		this.qtFnc = qtFnc;
	}

	public BigDecimal getQtPrvPrd() {
		return this.qtPrvPrd;
	}

	public void setQtPrvPrd(BigDecimal qtPrvPrd) {
		this.qtPrvPrd = qtPrvPrd;
	}

	public BigDecimal getTxPag() {
		return this.txPag;
	}

	public void setTxPag(BigDecimal txPag) {
		this.txPag = txPag;
	}

	public BigDecimal getVrDsb() {
		return this.vrDsb;
	}

	public void setVrDsb(BigDecimal vrDsb) {
		this.vrDsb = vrDsb;
	}

	public BigDecimal getVrFtEmp() {
		return this.vrFtEmp;
	}

	public void setVrFtEmp(BigDecimal vrFtEmp) {
		this.vrFtEmp = vrFtEmp;
	}

	public BigDecimal getVrRecBco() {
		return this.vrRecBco;
	}

	public void setVrRecBco(BigDecimal vrRecBco) {
		this.vrRecBco = vrRecBco;
	}

	public BigDecimal getVrRecPrp() {
		return this.vrRecPrp;
	}

	public void setVrRecPrp(BigDecimal vrRecPrp) {
		this.vrRecPrp = vrRecPrp;
	}

}