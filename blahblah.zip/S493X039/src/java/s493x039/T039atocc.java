package s493x039;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;


/**
 * The persistent class for the T039ATOC database table.
 * 
 */
@Entity
@Table(name="T039ATOCC", uniqueConstraints=@UniqueConstraint(columnNames= {"CD_AR_OPR","CD_AG","CD_CTR","NR_OPE","DT_MOV","CD_ATV_ECN"}))
@NamedQuery(name="T039atocc.findAll", query="SELECT t FROM T039atocc t")

public class T039atocc {
	
	@Id
	@GeneratedValue
	private Long id;
	
	@Column(name="CD_AR_OPR")
	private String cdArOpr;

	@Column(name="CD_AG", precision=4)
	private BigDecimal cdAg;
	
	@Column(name="CD_CTR")
	private String cdCtr;
	
	@Column(name="NR_OPE",precision=3)
	private long nrOpe;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DT_MOV")
	private java.util.Date dtMov;

	@Column(name="CD_ATV_ECN")
	private long cdAtvEcn;

	@Column(name="CD_SEC")
	private String cdSec;

	@Column(name="FT_ATV_ECN")
	private BigDecimal ftAtvEcn;

	@Column(name="VR_ATV_ECN",precision=18, scale=5)
	private BigDecimal vrAtvEcn;

	@Column(name="VS_CL")
	private BigDecimal vsCl;

	public T039atocc() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCdArOpr() {
		return cdArOpr;
	}

	public void setCdArOpr(String cdArOpr) {
		this.cdArOpr = cdArOpr;
	}

	public BigDecimal getCdAg() {
		return cdAg;
	}

	public void setCdAg(BigDecimal cdAg) {
		this.cdAg = cdAg;
	}

	public String getCdCtr() {
		return cdCtr;
	}

	public void setCdCtr(String cdCtr) {
		this.cdCtr = cdCtr;
	}

	public long getNrOpe() {
		return nrOpe;
	}

	public void setNrOpe(long nrOpe) {
		this.nrOpe = nrOpe;
	}

	public java.util.Date getDtMov() {
		return dtMov;
	}

	public void setDtMov(java.util.Date dtMov) {
		this.dtMov = dtMov;
	}

	public long getCdAtvEcn() {
		return cdAtvEcn;
	}

	public void setCdAtvEcn(long cdAtvEcn) {
		this.cdAtvEcn = cdAtvEcn;
	}

	public String getCdSec() {
		return cdSec;
	}

	public void setCdSec(String cdSec) {
		this.cdSec = cdSec;
	}

	public BigDecimal getFtAtvEcn() {
		return ftAtvEcn;
	}

	public void setFtAtvEcn(BigDecimal ftAtvEcn) {
		this.ftAtvEcn = ftAtvEcn;
	}

	public BigDecimal getVrAtvEcn() {
		return vrAtvEcn;
	}

	public void setVrAtvEcn(BigDecimal vrAtvEcn) {
		this.vrAtvEcn = vrAtvEcn;
	}

	public BigDecimal getVsCl() {
		return vsCl;
	}

	public void setVsCl(BigDecimal vsCl) {
		this.vsCl = vsCl;
	}

	

}