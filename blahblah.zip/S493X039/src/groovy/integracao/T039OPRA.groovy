package integracao

import org.apache.commons.lang.builder.HashCodeBuilder

class T039OPRA {
	
	String cd_ar_opr
	double cd_ag;
	String cd_ctr;
	double nr_ope;
	double cd_sis;
	double vr_ope_mn;
	double vr_ope_um;
	double nr_ult_fch;
	Date dt_ctr;
	Date dt_ven_ope;
	double cd_lim_opr;	
	double cd_pcr_ope;
	double tx_cst_ope;
	Date dt_rcr_ope;
	double aa_ref_bc;
	double nr_ref_bc;
	String dv_ref_bc;
	double pc_sub_ope
	double cd_moe_dsb
	String id_ope_prf
	String cd_vdr
	double cd_tit_crd
	String mt_adm_ope
	double id_pen_pag
	double id_exp_ope
	double cd_sit_crd
	double cd_tp_pes
	String cd_tp_rep
	double cd_apl_rec
	double cd_obj_ope
	double cd_mun_ope
	double cd_epd
	double id_ope_rfn
	double cd_tp_ast
	double cd_tp_rng
	double cd_amp_ope
	double cd_ope_esp
	Date dt_cad_seb
	double qt_ass_bfd
	double id_crd_rtv
	double id_agc_fam
	double nr_pes_ase
	Date dt_prc
	Date dt_ult_atz
	double cd_cli
	double cd_cli_prs
	double cd_cli_ass
	double aa_prp
	double nr_prp
	double tp_gp_cli
	Date dt_cad_ope
	double cd_tp_gar
	Date dt_pri_ree
	double vr_tx_jrs
	double cd_fx_ctr
	double cd_ag_prp
	double cd_cli_prj
	double id_rng_ori
	Date dt_adt
	double vr_crd_um
	double vr_crd_mn
	Date dh_atz
	String id_tot_fne
	Date dt_pri_acs
	double cd_tp_cbt
	double cd_fma_crd
	double id_tp_pag
	double cd_moe_atr
	double cd_moe_ref_atr
	double vr_tx_jrs_atr
	double vr_jrs_mor
	double cd_cli_aga
	String cd_pr_jrs
	String cd_pr_jrs_atr
	String cd_pr_mor
	double vr_tac
	double nr_ref_bc_ori
	String uniqueOPRA
	
	/*boolean equals(other) {
		if (!(other instanceof T039OPRA)) {
			return false
		}

		other.cd_ar_opr == cd_ar_opr && other.cd_ag == cd_ag && other.nr_ope == nr_ope
	}

	int hashCode() {
		def builder = new HashCodeBuilder()
		builder.append cd_ar_opr
		builder.append cd_ag
		builder.append nr_ope
		builder.toHashCode()
	}*/

	static mapping = {
		cd_ar_opr	column:	"CD_AR_OPR"	,sqlType:"char"	,length: 1
		cd_ag	column:	"CD_AG"	,sqlType:"decimal"	,precision: 4
		cd_ctr	column:	"CD_CTR"	,sqlType:"char"	,length: 10
		nr_ope	column:	"NR_OPE"	,sqlType:"decimal"	,precision: 3
		cd_sis	column:	"CD_SIS"	,sqlType:"decimal"	,precision: 4
		vr_ope_mn	column:	"VR_OPE_MN"	,sqlType:"decimal"	,precision: 17, scale:2
		vr_ope_um	column:	"VR_OPE_UM"	,sqlType:"decimal"	,precision: 17, scale:4
		nr_ult_fch	column:	"NR_ULT_FCH"	,sqlType:"decimal"	,precision: 3
		dt_ctr	column:	"DT_CTR"	,sqlType:"datetime"	
		dt_ven_ope	column:	"DT_VEN_OPE"	,sqlType:"datetime"	
		cd_lim_opr	column:	"CD_LIM_OPR"	,sqlType:"decimal"	,precision: 2
		cd_pcr_ope	column:	"CD_PCR_OPE"	,sqlType:"decimal"	,precision: 3
		tx_cst_ope	column:	"TX_CST_OPE"	,sqlType:"decimal"	,precision: 5, scale:2
		 dt_rcr_ope	column:	" DT_RCR_OPE"	,sqlType:"datetime"	
		aa_ref_bc	column:	"AA_REF_BC"	,sqlType:"decimal"	,precision: 4
		nr_ref_bc	column:	"NR_REF_BC"	,sqlType:"decimal"	,precision: 7
		dv_ref_bc	column:	"DV_REF_BC"	,sqlType:"char"	,length: 1
		pc_sub_ope	column:	"PC_SUB_OPE"	,sqlType:"decimal"	,precision: 2
		cd_moe_dsb	column:	"CD_MOE_DSB"	,sqlType:"decimal"	,precision: 5
		id_ope_prf	column:	"ID_OPE_PRF"	,sqlType:"char"	,length: 1
		cd_vdr	column:	"CD_VDR"	,sqlType:"char"	,length: 5
		cd_tit_crd	column:	"CD_TIT_CRD"	,sqlType:"decimal"	,precision: 2
		mt_adm_ope	column:	"MT_ADM_OPE"	,sqlType:"char"	,length: 7
		id_pen_pag	column:	"ID_PEN_PAG"	,sqlType:"decimal"	,precision: 1
		id_exp_ope	column:	"ID_EXP_OPE"	,sqlType:"decimal"	,precision: 1
		cd_sit_crd	column:	"CD_SIT_CRD"	,sqlType:"decimal"	,precision: 1
		cd_tp_pes	column:	"CD_TP_PES"	,sqlType:"decimal"	,precision: 1
		cd_tp_rep	column:	"CD_TP_REP"	,sqlType:"char"	,length: 10
		cd_apl_rec	column:	"CD_APL_REC"	,sqlType:"decimal"	,precision: 3
		cd_obj_ope	column:	"CD_OBJ_OPE"	,sqlType:"decimal"	,precision: 2
		cd_mun_ope	column:	"CD_MUN_OPE"	,sqlType:"decimal"	,precision: 5
		cd_epd	column:	"CD_EPD"	,sqlType:"decimal"	,precision: 17
		id_ope_rfn	column:	"ID_OPE_RFN"	,sqlType:"decimal"	,precision: 1
		cd_tp_ast	column:	"CD_TP_AST"	,sqlType:"decimal"	,precision: 1
		cd_tp_rng	column:	"CD_TP_RNG"	,sqlType:"decimal"	,precision: 1
		cd_amp_ope	column:	"CD_AMP_OPE"	,sqlType:"decimal"	,precision: 1
		cd_ope_esp	column:	"CD_OPE_ESP"	,sqlType:"decimal"	,precision: 1
		dt_cad_seb	column:	"DT_CAD_SEB"	,sqlType:"datetime"	
		qt_ass_bfd	column:	"QT_ASS_BFD"	,sqlType:"decimal"	,precision: 5
		id_crd_rtv	column:	"ID_CRD_RTV"	,sqlType:"decimal"	,precision: 1
		id_agc_fam	column:	"ID_AGC_FAM"	,sqlType:"decimal"	,precision: 1
		nr_pes_ase	column:	"NR_PES_ASE"	,sqlType:"decimal"	,precision: 5
		dt_prc	column:	"DT_PRC"	,sqlType:"datetime"	
		dt_ult_atz	column:	"DT_ULT_ATZ"	,sqlType:"datetime"	
		cd_cli	column:	"CD_CLI"	,sqlType:"decimal"	,precision: 10
		cd_cli_prs	column:	"CD_CLI_PRS"	,sqlType:"decimal"	,precision: 10
		cd_cli_ass	column:	"CD_CLI_ASS"	,sqlType:"decimal"	,precision: 10
		aa_prp	column:	"AA_PRP"	,sqlType:"decimal"	,precision: 4
		nr_prp	column:	"NR_PRP"	,sqlType:"decimal"	,precision: 7
		tp_gp_cli	column:	"TP_GP_CLI"	,sqlType:"decimal"	,precision: 2
		dt_cad_ope	column:	"DT_CAD_OPE"	,sqlType:"datetime"	
		cd_tp_gar	column:	"CD_TP_GAR"	,sqlType:"decimal"	,precision: 2
		dt_pri_ree	column:	"DT_PRI_REE"	,sqlType:"datetime"	
		vr_tx_jrs	column:	"VR_TX_JRS"	,sqlType:"decimal"	,precision: 9, scale: 4
		cd_fx_ctr	column:	"CD_FX_CTR"	,sqlType:"decimal"	,precision: 2
		cd_ag_prp	column:	"CD_AG_PRP"	,sqlType:"decimal"	,precision: 4
		cd_cli_prj	column:	"CD_CLI_PRJ"	,sqlType:"decimal"	,precision: 10
		id_rng_ori	column:	"ID_RNG_ORI"	,sqlType:"decimal"	,precision: 1
		dt_adt	column:	"DT_ADT"	,sqlType:"datetime"	
		vr_crd_um	column:	"VR_CRD_UM"	,sqlType:"decimal"	,precision: 17, scale: 4
		vr_crd_mn	column:	"VR_CRD_MN"	,sqlType:"decimal"	,precision: 17, scale: 2
		dh_atz	column:	"DH_ATZ"	,sqlType:"datetime"	
		id_tot_fne	column:	"ID_TOT_FNE"	,sqlType:"varchar"	,length: 1
		dt_pri_acs	column:	"DT_PRI_ACS"	,sqlType:"datetime"	
		cd_tp_cbt	column:	"CD_TP_CBT"	,sqlType:"decimal"	,precision: 1
		cd_fma_crd	column:	"CD_FMA_CRD"	,sqlType:"decimal"	,precision: 1
		id_tp_pag	column:	"ID_TP_PAG"	,sqlType:"decimal"	,precision: 1
		cd_moe_atr	column:	"CD_MOE_ATR"	,sqlType:"decimal"	,precision: 5
		cd_moe_ref_atr	column:	"CD_MOE_REF_ATR"	,sqlType:"decimal"	,precision: 5
		vr_tx_jrs_atr	column:	"VR_TX_JRS_ATR"	,sqlType:"decimal"	,precision: 9, scale: 4
		vr_jrs_mor	column:	"VR_JRS_MOR"	,sqlType:"decimal"	,precision: 9, scale: 4
		cd_cli_aga	column:	"CD_CLI_AGA"	,sqlType:"decimal"	,precision: 10
		cd_pr_jrs	column:	"CD_PR_JRS"	,sqlType:"char"	,length: 1
		cd_pr_jrs_atr	column:	"CD_PR_JRS_ATR"	,sqlType:"char"	,length: 1
		cd_pr_mor	column:	"CD_PR_MOR"	,sqlType:"char", lenghts:1
		vr_tac	column:	"VR_TAC"	,sqlType:"decimal"	,precision: 8, scale: 4
		nr_ref_bc_ori	column:	"NR_REF_BC_ORI"	,sqlType:"varchar"	,length: 1

	}
	
    static constraints = {
		uniqueOPRA nullable:true, unique:['cd_ar_opr','cd_ag','cd_ctr','nr_ope']
		cd_ar_opr nullable:false, blank:false, maxSize:1
		cd_ag nullable:false, blank:false, maxSize:4
		cd_ctr nullable:false, blank:false, maxSize:10
		nr_ope nullable:false, blank:false, maxSize:3
		vr_ope_mn nullable:false, blank:false, maxSize:17, scale:2
		vr_ope_um nullable:false, blank:false, maxSize:17, scale:4
		nr_ult_fch nullable:false, blank:false, maxSize:3 
		dt_ctr nullable:false, blank:false
		dt_ven_ope nullable:false, blank:false
		cd_lim_opr nullable:true, blank:false, maxSize:2
		
		cd_pcr_ope nullable:true, blank:false, maxSize:3
		tx_cst_ope nullable:false, blank:false, maxSize:5, scale:2
		dt_rcr_ope nullable:true, blank:false
		aa_ref_bc nullable:false, blank:false, maxSize:4
		nr_ref_bc nullable:false, blank:false, maxSize:7
		dv_ref_bc nullable:false, blank:false, maxSize:1
		pc_sub_ope nullable:false, blank:false, maxSize:2
		cd_moe_dsb nullable:true, blank:false, maxSize:5
		id_ope_prf nullable:false, blank:false, maxSize:1
		cd_vdr nullable:true, blank:false, maxSize:5
		cd_tit_crd nullable:true, blank:false, maxSize:2
		mt_adm_ope nullable:false, blank:false, maxSize:7
		id_pen_pag nullable:false, blank:false, maxSize:1
		id_exp_ope nullable:false, blank:false, maxSize:1
		cd_sit_crd nullable:false, blank:false, maxSize:1
		cd_tp_pes nullable:false, blank:false, maxSize:1
		cd_tp_rep nullable:false, blank:false, maxSize:10
		cd_apl_rec nullable:true, blank:false, maxSize:3
		cd_obj_ope nullable:true, blank:false, maxSize:2
		cd_mun_ope nullable:false, blank:false, maxSize:5
		cd_epd nullable:true, blank:false, maxSize:17
		id_ope_rfn nullable:false, blank:false, maxSize:1
		cd_tp_ast nullable:false, blank:false, maxSize:1
		cd_tp_rng nullable:false, blank:false, maxSize:1
		cd_amp_ope nullable:false, blank:false, maxSize:1
		cd_ope_esp nullable:false, blank:false, maxSize:1
		dt_cad_seb nullable:true, blank:false
		qt_ass_bfd nullable:true, blank:false, maxSize:5
		id_crd_rtv nullable:true, blank:false, maxSize:1
		id_agc_fam nullable:true, blank:false, maxSize:1
		nr_pes_ase nullable:true, blank:false, maxSize:5
		dt_prc nullable:false, blank:false
		dt_ult_atz nullable:false, blank:false
		cd_cli nullable:true, blank:false, maxSize:10
		cd_cli_prs nullable:true, blank:false, maxSize:10
		cd_cli_ass nullable:true, blank:false, maxSize:10
		aa_prp nullable:true, blank:false, maxSize:4
		nr_prp nullable:true, blank:false, maxSize:7
		tp_gp_cli nullable:true, blank:false, maxSize:2
		dt_cad_ope nullable:false, blank:false
		cd_tp_gar nullable:true, blank:false, maxSize:2
		dt_pri_ree nullable:false, blank:false
		vr_tx_jrs nullable:false, blank:false, maxSize:9, scale:4
		cd_fx_ctr nullable:false, blank:false, maxSize:2
		cd_ag_prp nullable:true, blank:false, maxSize:4
		cd_cli_prj nullable:true, blank:false, maxSize:10
		id_rng_ori nullable:true, blank:false, maxSize:1
		dt_adt nullable:true, blank:false
		vr_crd_um nullable:true, blank:false, maxSize:17, scale:4
		vr_crd_mn nullable:true, blank:false, maxSize:17, scale:2
		dh_atz nullable:true, blank:false
		id_tot_fne nullable:true, blank:false, maxSize:1
		dt_pri_acs nullable:true, blank:false
		cd_tp_cbt nullable:true, blank:false, maxSize:1
		cd_fma_crd nullable:true, blank:false, maxSize:1
		id_tp_pag nullable:true, blank:false, maxSize:1
		cd_moe_atr nullable:true, blank:false, maxSize:5
		cd_moe_ref_atr nullable:true, blank:false, maxSize:5
		vr_tx_jrs_atr nullable:true, blank:false, maxSize:9, scale:4
		vr_jrs_mor nullable:true, blank:false, maxSize:9, scale:4
		cd_cli_aga nullable:true, blank:false, maxSize:10
		cd_pr_jrs nullable:true, blank:false, maxSize:1
		cd_pr_jrs_atr nullable:true, blank:false, maxSize:1
		cd_pr_mor nullable:true, blank:false, maxSize:1
		vr_tac nullable:true, blank:false, maxSize:8, scale:4
		nr_ref_bc_ori nullable:true, blank:false, maxSize:11
	
				
		
	}
	
}