package integracao

class T039AVAL {
		String	cd_ar_opr
		double	cd_ag
		String	cd_ctr
		double	nr_ope
		double	cd_cli
		double	cd_tp_coo
		String uniqueAVAL
	
	static mapping = {
		cd_ar_opr	column:	"CD_AR_OPR"	,sqlType:"char"	,length:1
		cd_ag	column:	"CD_AG"	,sqlType:"decimal"	,decimal:4
		cd_ctr	column:	"CD_CTR"	,sqlType:"char"	,length:10
		nr_ope	column:	"NR_OPE"	,sqlType:"decimal"	,decimal:3
		cd_cli	column:	"CD_CLI"	,sqlType:"decimal"	,decimal:10
		cd_tp_coo	column:	"CD_TP_COO"	,sqlType:"decimal"	,decimal:2
	
	}
	
    static constraints = {
		uniqueAVAL nullable:true,blank:false, unique:['cd_ar_opr','cd_ag','cd_ctr','nr_ope','cd_cli','cd_tp_coo']
		cd_ar_opr nullable:false, blank:false, maxSize:1
		cd_ag	nullable:false, blank:false, maxSize:4
		cd_ctr	nullable:false, blank:false, maxSize:10
		nr_ope	nullable:false, blank:false, maxSize:3
		cd_cli	nullable:false, blank:false, maxSize:10
		cd_tp_coo	nullable:false, blank:false, maxSize:2
		
    }
}
