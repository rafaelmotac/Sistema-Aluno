package integracao

class T039FIXA {
	String	cd_ar_opr
	float	cd_ag
	String	cd_ctr
	double	nr_ope
	double	cd_fma_qit
	Date	dt_ult_hst
	Date	dt_ult_atz
	String	id_evt_rea
	Date	dh_atz
	String uniqueFIXA
	
	static mapping = {
		cd_ar_opr	column:	"CD_AR_OPR"	,sqlType:"char"	,length:1
		cd_ag	column:	"CD_AG"	//,sqlType:"decimal"	,precision:4
		cd_ctr	column:	"CD_CTR"	,sqlType:"char"	,length:10
		nr_ope	column:	"NR_OPE"	,sqlType:"decimal"	,precision:3
		cd_fma_qit	column:	"CD_FMA_QIT"	,sqlType:"decimal"	,precision:1
		dt_ult_hst	column:	"DT_ULT_HST"	,sqlType:"datetime"	
		id_evt_rea	column:	"ID_EVT_REA"	,sqlType:"char"	,length:1
		dt_ult_atz	column:	"DT_ULT_ATZ"	,sqlType:"datetime"	
		dh_atz	column:	"DH_ATZ"	,sqlType:"datetime"			
	}
	
    static constraints = {
		uniqueFIXA nullable:true, unique:['cd_ar_opr','cd_ag','cd_ctr','nr_ope']
		cd_ar_opr nullable:false, blank:false, maxSize:1
		cd_ag	nullable:false, blank:false
		cd_ctr	nullable:false, blank:false, maxSize:10
		nr_ope	nullable:false, blank:false, maxSize:3
		cd_fma_qit	nullable:false, blank:false, maxSize:1
		dt_ult_hst	nullable:true, blank:false
		dt_ult_atz	nullable:true, blank:false
		id_evt_rea	nullable:true, blank:false, maxSize:1
		dh_atz	nullable:true, blank:false
		
    }
}
