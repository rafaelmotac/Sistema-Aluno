package integracao

import org.apache.commons.lang.builder.HashCodeBuilder

class T039HFIX {
	
	//T039TFIN t039tfin
	String	cd_ar_opr
	double	cd_ag
	String	cd_ctr
	double	nr_ope
	Date	dt_vig_fch
	double	cd_tp_cta
	double	cd_set_atv
	double	id_sub
	double	cd_tp_crd
	double	cd_tp_bnf
	double	cd_dst_rec
	double	id_ctp_bid
	double	id_sma
	//double	cd_fin_fnc //foreign key T039TFIN
	double	id_irr
	double	cd_tp_cor
	double	cd_fte_rec
	double	cd_prg_crd
	double	cd_tp_pes
	double	cd_cat_prd
	double	id_sit_fch
	double	cd_tp_rec
	double	cd_moe
	double	cd_moe_ref
	double	id_gar
	Date	dt_prc
	double	cd_ctb_atr
	double	cd_ctb_nrm
	double	cd_rap_atr
	double	cd_rap_nrm
	Date	dh_atz
	double	id_ope_alg
	double	cd_sis
	double	cd_fin_ope_ori
	double	cd_rsc_fne
	double 	cd_atv
	String uniqueHFIX
	
	static belongsTo = [t039tfin:T039TFIN]
	
	/*boolean equals(other) {
		if (!(other instanceof T039OPRA)) {
			return false
		}

		other.identity == id && other.cd_ar_opr == cd_ar_opr && other.cd_ag == cd_ag && other.nr_ope == nr_ope
	}

	int hashCode() {
		def builder = new HashCodeBuilder()
		builder.append id
		builder.append cd_ar_opr
		builder.append cd_ag
		builder.append nr_ope
		builder.toHashCode()
	}*/

	static mapping = {
		cd_ar_opr	column:	"CD_AR_OPR"	,sqlType:"char"	,length:1
		cd_ag	column:	"CD_AG"	,sqlType:"decimal"	,precision:4
		cd_ctr	column:	"CD_CTR"	,sqlType:"char"	,length:10
		nr_ope	column:	"NR_OPE"	,sqlType:"decimal"	,precision:3
		dt_vig_fch	column:	"DT_VIG_FCH"	,sqlType:"datetime"	
		cd_tp_cta	column:	"CD_TP_CTA"	,sqlType:"decimal"	,precision:2
		cd_set_atv	column:	"CD_SET_ATV"	,sqlType:"decimal"	,precision:1
		id_sub	column:	"ID_SUB"	,sqlType:"decimal"	,precision:1
		cd_tp_crd	column:	"CD_TP_CRD"	,sqlType:"decimal"	,precision:1
		cd_tp_bnf	column:	"CD_TP_BNF"	,sqlType:"decimal"	,precision:2
		cd_dst_rec	column:	"CD_DST_REC"	,sqlType:"decimal"	,precision:2
		id_ctp_bid	column:	"ID_CTP_BID"	,sqlType:"decimal"	,precision:1
		id_sma	column:	"ID_SMA"	,sqlType:"decimal"	,precision:1
		//t039tfin	column:	"CD_FIN_FNC"	,sqlType:"decimal"	,precision:3
		id_irr	column:	"ID_IRR"	,sqlType:"decimal"	,precision:1
		cd_tp_cor	column:	"CD_TP_COR"	,sqlType:"decimal"	,precision:1
		cd_fte_rec	column:	"CD_FTE_REC"	,sqlType:"decimal"	,precision:3
		cd_prg_crd	column:	"CD_PRG_CRD"	,sqlType:"decimal"	,precision:4
		cd_tp_pes	column:	"CD_TP_PES"	,sqlType:"decimal"	,precision:1
		cd_cat_prd	column:	"CD_CAT_PRD"	,sqlType:"decimal"	,precision:3
		id_sit_fch	column:	"ID_SIT_FCH"	,sqlType:"decimal"	,precision:1
		cd_tp_rec	column:	"CD_TP_REC"	,sqlType:"decimal"	,precision:2
		cd_moe	column:	"CD_MOE"	,sqlType:"decimal"	,precision:5
		cd_moe_ref	column:	"CD_MOE_REF"	,sqlType:"decimal"	,precision:5
		id_gar	column:	"ID_GAR"	,sqlType:"decimal"	,precision:1
		dt_prc	column:	"DT_PRC"	,sqlType:"datetime"	
		cd_ctb_nrm	column:	"CD_CTB_NRM"	,sqlType:"decimal"	,precision:10
		cd_ctb_atr	column:	"CD_CTB_ATR"	,sqlType:"decimal"	,precision:10
		cd_rap_nrm	column:	"CD_RAP_NRM"	,sqlType:"decimal"	,precision:10
		cd_rap_atr	column:	"CD_RAP_ATR"	,sqlType:"decimal"	,precision:10
		dh_atz	column:	"DH_ATZ"	,sqlType:"datetime"	
		id_ope_alg	column:	"ID_OPE_ALG"	,sqlType:"decimal"	,precision:1
		cd_sis	column:	"CD_SIS"	,sqlType:"decimal"	,precision:4
		cd_fin_ope_ori	column:	"CD_FIN_OPE_ORI"	,sqlType:"decimal"	,precision:2
		cd_rsc_fne	column:	"CD_RSC_FNE"	,sqlType:"decimal"	,precision:2

		
	}
	
    static constraints = {	
		uniqueHFIX nullable:true, unique:['cd_ar_opr','cd_ag','cd_ctr','nr_ope','dt_vig_fch']
		cd_ar_opr	nullable:false, blank:false, maxSize:1
		cd_ag	nullable:false, blank:false, maxSize:4
		cd_ctr	nullable:false, blank:false, maxSize:10
		nr_ope	nullable:false, blank:false, maxSize:3
		dt_vig_fch	nullable:false, blank:false
		cd_tp_cta	nullable:false, blank:false, maxSize:2
		cd_set_atv	nullable:true, blank:false, maxSize:1
		id_sub	nullable:true, blank:false, maxSize:1
		cd_tp_crd	nullable:true, blank:false, maxSize:1
		cd_tp_bnf	nullable:false, blank:false, maxSize:2
		cd_dst_rec	nullable:true, blank:false, maxSize:2
		id_ctp_bid	nullable:false, blank:false, maxSize:1
		id_sma	nullable:false, blank:false, maxSize:1
		//cd_fin_fnc	nullable:false, blank:false, maxSize:2
		id_irr	nullable:false, blank:false, maxSize:1
		cd_tp_cor	nullable:false, blank:false, maxSize:1
		cd_fte_rec	nullable:false, blank:false, maxSize:3
		cd_prg_crd	nullable:false, blank:false, maxSize:4
		cd_tp_pes	nullable:false, blank:false, maxSize:1
		cd_cat_prd	nullable:false, blank:false, maxSize:3
		id_sit_fch	nullable:false, blank:false, maxSize:1
		cd_tp_rec	nullable:true, blank:false, maxSize:2
		cd_moe	nullable:false, blank:false, maxSize:5
		cd_moe_ref	nullable:true, blank:false, maxSize:5
		id_gar	nullable:false, blank:false, maxSize:1
		dt_prc	nullable:false, blank:false
		cd_ctb_atr	nullable:true, blank:false, maxSize:6
		cd_ctb_nrm	nullable:true, blank:false, maxSize:6
		cd_rap_atr	nullable:true, blank:false, maxSize:6
		cd_rap_nrm	nullable:true, blank:false, maxSize:6
		dh_atz	nullable:false, blank:false
		id_ope_alg	nullable:true, blank:false, maxSize:1
		cd_sis	nullable:true, blank:false, maxSize:4
		cd_fin_ope_ori	nullable:true, blank:false, maxSize:2
		cd_rsc_fne	nullable:true, blank:false, maxSize:2
		cd_atv nullable:false,blank:false, maxSize:5, scale:3
		
    }
}
