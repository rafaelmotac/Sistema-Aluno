package integracao

class T039MOED {

    static constraints = {
    }
}
