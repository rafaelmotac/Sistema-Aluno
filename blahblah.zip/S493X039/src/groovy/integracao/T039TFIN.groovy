package integracao

class T039TFIN {
	double cd_fin_fnc
	String nm_fin_fnc
	
	String toString(){
		def nome = "${cd_fin_fnc} - ${nm_fin_fnc}"
		return nome
	}
	
	static hasMany = [T039HFIX t039hfix]
	
	static mapping = {
		cd_fin_fnc column: 'CD_FIN_FNC'//, sqlType: "decimal"//,precision:3
		nm_fin_fnc column: 'NM_FIN_FNC'//,sqlType: "char"//, lenght: 30
	}
    static constraints = {
		cd_fin_fnc nullable:false, blank:false, unique:true, maxSize:3
		nm_fin_fnc nullable:true, blank:false, maxSize:30
    }
}
