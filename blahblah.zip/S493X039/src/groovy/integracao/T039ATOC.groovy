package integracao

class T039ATOC {
		String	cd_ar_opr
		float	cd_ag
		String	cd_ctr
		double	nr_ope
		Date	dt_mov
		double	vr_atv_ecn
		double	cd_atv_ecn
		double	ft_atv_ecn
		Date	dataReferencia
		String 	uniqueATOC
		
		
	static mapping = {
		cd_ar_opr	column:	"CD_AR_OPR"	,sqlType:"char"	,length:1
		cd_ag	column:	"CD_AG"	//,sqlType:"decimal" ,precision:4
		cd_ctr	column:	"CD_CTR"	,sqlType:"char"	,length:10
		nr_ope	column:	"NR_OPE"	,sqlType:"decimal"	,precision:3
		dt_mov	column:	"DT_MOV"	,sqlType:"datetime"	
		cd_atv_ecn	column:	"CD_ATV_ECN"	,sqlType:"decimal"	,precision:11
		//vr_atv_ecn	column:	"VR_ATV_ECN"	//,sqlType:"decimal"	,precision:18, scale:2	
		ft_atv_ecn	column:	"FT_ATV_ECN"	,sqlType:"decimal"	,precision:5, scale:4
		//dataReferencia column: "DT_REF_OPR"

	}
    static constraints = {
		uniqueATOC nullable:true,blank:false, unique:['cd_ar_opr','cd_ag','cd_ctr','nr_ope','dt_mov','cd_atv_ecn','dataReferencia']
		cd_ar_opr nullable:false, blank:false, maxSize:1
		cd_ag	nullable:false, blank:false, maxSize:4,scale:2
		cd_ctr	nullable:false, blank:false, maxSize:10
		nr_ope	nullable:false, blank:false, maxSize:3
		dt_mov	nullable:false, blank:false
		vr_atv_ecn	nullable:false, blank:false, maxSize:18, scale:2
		cd_atv_ecn	nullable:false, blank:false, maxSize:11
		ft_atv_ecn	nullable:false, blank:false, maxSize:5, scale:4		
    }
}
