package integracao

class T039EMPD {
	String	cd_ar_opr
	double	cd_ag
	String	cd_ctr
	double	nr_ope
	double	 cd_imv
	double	 cd_epd
	double	 vr_rec_bco
	double	 vr_rec_prp
	double	 qt_prv_prd
	String	 pr_sfr
	double	 tx_pag
	double	 qt_fnc
	double	 nm_und_fnc
	double	 qt_ar_fnc
	double	 vr_dsb
	double	 vr_ft_emp
	Date	 dt_ref
	String uniqueEMPD
	
	static mapping = {
		cd_ar_opr	column:	"CD_AR_OPR"	,sqlType:"char"	,length:1
		cd_ag	column:	"CD_AG"	,sqlType:"decimal"	,precision:4
		cd_ctr	column:	"CD_CTR"	,sqlType:"char"	,length:10
		nr_ope	column:	"NR_OPE"	,sqlType:"decimal"	,precision:3
		cd_imv	column:	"CD_IMV"	,sqlType:"datetime"	,precision:2
		cd_epd	column:	"CD_EPD"	,sqlType:"decimal"	,precision:17
		vr_rec_bco	column:	"VR_REC_BCO"	,sqlType:"decimal"	,precision:18,scale:2
		vr_rec_prp	column:	"VR_REC_PRP"	,sqlType:"decimal"	,precision:18,scale:2
		qt_prv_prd	column:	"QT_PRV_PRD"	,sqlType:"decimal"	,precision: 9,scale:2
		pr_sfr	column:	"PR_SFR"	,sqlType:"varchar"	,length:8
		tx_pag	column:	"TX_PAG"	,sqlType:"decimal"	,precision:5 ,scale:2
		qt_fnc	column:	"QT_FNC"	,sqlType:"decimal"	,precision: 11,scale:2
		nm_und_fnc	column:	"NM_UND_FNC"	,sqlType:"varchar"	,length:10
		qt_ar_fnc	column:	"QT_AR_FNC"	,sqlType:"decimal"	,precision: 9,scale:2
		vr_dsb	column:	"VR_DSB"	,sqlType:"decimal"	,precision: 18,scale:2
		vr_ft_emp	column:	"VR_FT_EMP"	,sqlType:"decimal"	,precision: 18,scale:2
		dt_ref	column:	"DT_REF"	,sqlType:"datetime"	

		
	}
    static constraints = {
		 uniqueEMPD nullable:true,blank:false, unique:['cd_ar_opr','cd_ag','cd_ctr','nr_ope','cd_imv','cd_epd']
		 cd_ar_opr	nullable:false, blank:false, maxSize:1
		 cd_ag	nullable:false, blank:false, maxSize:4
		 cd_ctr	nullable:false, blank:false, maxSize:10
		 nr_ope	nullable:false, blank:false, maxSize:3
		 cd_imv	nullable:false, blank:false, maxSize:2
		 cd_epd	nullable:false, blank:false, maxSize:17
		 vr_rec_bco	nullable:false, blank:false, maxSize:18, scale:2
		 vr_rec_prp	nullable:false, blank:false, maxSize:18, scale:2
		 qt_prv_prd	nullable:false, blank:false, maxSize:9, scale:2
		 pr_sfr	nullable:true, blank:false, maxSize:8
		 tx_pag	nullable:true, blank:false, maxSize:5, scale:2
		 qt_fnc	nullable:true, blank:false, maxSize:11, scale:2
		 nm_und_fnc	nullable:true, blank:false, maxSize:10
		 qt_ar_fnc	nullable:false, blank:false, maxSize:9, scale:2
		 vr_dsb	nullable:false, blank:false, maxSize:18, scale:2
		 vr_ft_emp	nullable:false, blank:false, maxSize:18, scale:2
		 dt_ref	nullable:false, blank:false
		
    }
}
