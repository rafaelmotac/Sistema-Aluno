package integracao

class T039REEM {
		String	cd_ar_opr
		double	cd_ag
		String	cd_ctr
		double	nr_ope
		Date	dt_mov
		double	sq_ree
		Date	dt_ree
		double	vr_ree
		double	pc_ree
		double	qt_pcl
		String uniqueREEM
	
	static mapping ={	
		cd_ar_opr	column:	"CD_AR_OPR"	,sqlType:"char"	,length:1
		cd_ag	column:	"CD_AG"	,sqlType:"decimal"	,precision:4
		cd_ctr	column:	"CD_CTR"	,sqlType:"char"	,length:10
		nr_ope	column:	"NR_OPE"	,sqlType:"decimal"	,precision:3
		dt_mov	column:	"DT_MOV"	,sqlType:"datetime"	
		sq_ree	column:	"SQ_REE"	,sqlType:"decimal"	,precision:3
		dt_ree	column:	"DT_REE"	,sqlType:"datetime"	
		vr_ree	column:	"VR_REE"	,sqlType:"decimal"	,precision:18 ,scale:2
		pc_ree	column:	"PC_REE"	,sqlType:"decimal"	,precision:18 ,scale:2
		qt_pcl	column:	"QT_PCL"	,sqlType:"decimal"	,precision:3		
	}
    static constraints = {
		uniqueREEM nullable:true,blank:true, unique:['cd_ar_opr','cd_ag','cd_ctr','nr_ope','dt_mov','sq_ree','dt_ree']
		cd_ar_opr	nullable:false, blank:false, maxSize:1
		cd_ag	nullable:false, blank:false, maxSize:4
		cd_ctr	nullable:false, blank:false, maxSize:10
		nr_ope	nullable:false, blank:false, maxSize:3
		dt_mov	nullable:false, blank:false
		sq_ree	nullable:false, blank:false, maxSize:3
		dt_ree	nullable:false, blank:false
		vr_ree	nullable:false, blank:false, maxSize:18, scale:2
		pc_ree	nullable:true, blank:false, maxSize:18, scale:2
		qt_pcl	nullable:false, blank:false, maxSize:3
		
    }
}
