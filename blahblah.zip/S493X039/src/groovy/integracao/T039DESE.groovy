package integracao

class T039DESE {
		Date	dt_mov
		String	cd_ar_opr
		double	cd_ag
		String	cd_ctr
		double	nr_ope
		int	sq_dsb
		double	cd_tp_mov
		Date	dt_dsb
		double	vr_dsb
		String 	uniqueDESE
		
	
		static mapping = {
			dt_mov	column:	"DT_MOV"	,sqlType:"datetime"	
			cd_ar_opr	column:	"CD_AR_OPR"	,sqlType:"char"	,length:1
			cd_ag	column:	"CD_AG"	,sqlType:"decimal"	,precision:4
			cd_ctr	column:	"CD_CTR"	,sqlType:"char"	,length:10
			nr_ope	column:	"NR_OPE"	,sqlType:"decimal"	,precision:4
			sq_dsb	column:	"SQ_DSB"	,sqlType:"integer"	
			cd_tp_mov	column:	"CD_TP_MOV"	,sqlType:"decimal"	,precision:3
			dt_dsb	column:	"DT_DSB"	,sqlType:"datetime"	
			vr_dsb	column:	"VR_DSB"	,sqlType:"decimal"	,precision:18,scale:4
	
		}
	
		static constraints = {
			uniqueDESE nullable:true,blank:false, unique:['cd_ar_opr','dt_mov','cd_ag','cd_ctr','nr_ope','sq_dsb','cd_tp_mov','dt_dsb']
			dt_mov	nullable:false, blank:false//, unique:['cd_ar_opr','dt_mov','cd_ag','cd_ctr','nr_ope','sq_dsb','cd_tp_mov','dt_dsb']
			cd_ar_opr nullable:false, blank:false, maxSize:1
			cd_ag	nullable:false, blank:false, maxSize:4
			cd_ctr	nullable:false, blank:false, maxSize:10
			nr_ope	nullable:false, blank:false, maxSize:4
			sq_dsb	nullable:false, blank:false
			cd_tp_mov	nullable:false, blank:false, maxSize:3
			dt_dsb	nullable:false, blank:false
			vr_dsb	nullable:false, blank:false, maxSize:18, scale:4	
		}
}
