package integracao

import org.apache.commons.lang.builder.HashCodeBuilder

class Usuario implements Serializable {
	Integer cod_usu
	String	cod_log_usu
	String	dsc_usu
	String	flg_sta_usu
	Date	dat_val_usu
	String	nom_usu
	String	flg_usu_adm
	String	flg_sen_prx_log
	String	flg_alt_sen
	Integer		cod_usu_ult_mnt
	String	flg_reu_sen
	Date	dat_ult_mnt
	String	dsc_ema_usu
	Byte	img_asi_elt_usu
	
	boolean equals(other) {
    if (!(other instanceof Usuario)) {
        return false
    }

    other.cod_usu == cod_usu && other.cod_log_usu == cod_log_usu
    }

	int hashCode() {
	def builder = new HashCodeBuilder()
	builder.append cod_usu
	builder.append cod_log_usu
	builder.toHashCode()
	}
	

	static mapping = {
		table 'usuario'
		version false
		id composite:["cod_usu", "cod_log_usu"] 
		cod_usu sqlType:"int" 
		cod_log_usu sqlType:"varchar", lenght:40
		dsc_usu sqlType:"varchar", lenght:40
		flg_sta_usu sqlType:"char", lenght:1
		dat_val_usu sqlType:"datetime"
		nom_usu sqlType:"varchar" , lenght:40
		flg_usu_adm sqlType:"char" , lenght:1
		flg_sen_prx_log sqlType:"char", lenght:1
		flg_alt_sen sqlType:"char", lenght:1
		cod_usu_ult_mnt sqlType:"int" 
		flg_reu_sen sqlType:"char", lenght:1
		dat_ult_mnt sqlType:"datetime" 
		dsc_ema_usu sqlType:"varchar" ,length:80
		img_asi_elt_usu sqlType:"image", length:16
		
	}
	
    static constraints = {
    }
}
