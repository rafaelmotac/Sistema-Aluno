package s493x039



import grails.test.mixin.*
import spock.lang.*

@TestFor(SaldoFaixaController)
@Mock(SaldoFaixa)
class SaldoFaixaControllerSpec extends Specification {

    def populateValidParams(params) {
        assert params != null
        // TODO: Populate valid properties like...
        //params["name"] = 'someValidName'
    }

    void "Test the index action returns the correct model"() {

        when:"The index action is executed"
            controller.index()

        then:"The model is correct"
            !model.saldoFaixaInstanceList
            model.saldoFaixaInstanceCount == 0
    }

    void "Test the create action returns the correct model"() {
        when:"The create action is executed"
            controller.create()

        then:"The model is correctly created"
            model.saldoFaixaInstance!= null
    }

    void "Test the save action correctly persists an instance"() {

        when:"The save action is executed with an invalid instance"
            request.contentType = FORM_CONTENT_TYPE
            request.method = 'POST'
            def saldoFaixa = new SaldoFaixa()
            saldoFaixa.validate()
            controller.save(saldoFaixa)

        then:"The create view is rendered again with the correct model"
            model.saldoFaixaInstance!= null
            view == 'create'

        when:"The save action is executed with a valid instance"
            response.reset()
            populateValidParams(params)
            saldoFaixa = new SaldoFaixa(params)

            controller.save(saldoFaixa)

        then:"A redirect is issued to the show action"
            response.redirectedUrl == '/saldoFaixa/show/1'
            controller.flash.message != null
            SaldoFaixa.count() == 1
    }

    void "Test that the show action returns the correct model"() {
        when:"The show action is executed with a null domain"
            controller.show(null)

        then:"A 404 error is returned"
            response.status == 404

        when:"A domain instance is passed to the show action"
            populateValidParams(params)
            def saldoFaixa = new SaldoFaixa(params)
            controller.show(saldoFaixa)

        then:"A model is populated containing the domain instance"
            model.saldoFaixaInstance == saldoFaixa
    }

    void "Test that the edit action returns the correct model"() {
        when:"The edit action is executed with a null domain"
            controller.edit(null)

        then:"A 404 error is returned"
            response.status == 404

        when:"A domain instance is passed to the edit action"
            populateValidParams(params)
            def saldoFaixa = new SaldoFaixa(params)
            controller.edit(saldoFaixa)

        then:"A model is populated containing the domain instance"
            model.saldoFaixaInstance == saldoFaixa
    }

    void "Test the update action performs an update on a valid domain instance"() {
        when:"Update is called for a domain instance that doesn't exist"
            request.contentType = FORM_CONTENT_TYPE
            request.method = 'PUT'
            controller.update(null)

        then:"A 404 error is returned"
            response.redirectedUrl == '/saldoFaixa/index'
            flash.message != null


        when:"An invalid domain instance is passed to the update action"
            response.reset()
            def saldoFaixa = new SaldoFaixa()
            saldoFaixa.validate()
            controller.update(saldoFaixa)

        then:"The edit view is rendered again with the invalid instance"
            view == 'edit'
            model.saldoFaixaInstance == saldoFaixa

        when:"A valid domain instance is passed to the update action"
            response.reset()
            populateValidParams(params)
            saldoFaixa = new SaldoFaixa(params).save(flush: true)
            controller.update(saldoFaixa)

        then:"A redirect is issues to the show action"
            response.redirectedUrl == "/saldoFaixa/show/$saldoFaixa.id"
            flash.message != null
    }

    void "Test that the delete action deletes an instance if it exists"() {
        when:"The delete action is called for a null instance"
            request.contentType = FORM_CONTENT_TYPE
            request.method = 'DELETE'
            controller.delete(null)

        then:"A 404 is returned"
            response.redirectedUrl == '/saldoFaixa/index'
            flash.message != null

        when:"A domain instance is created"
            response.reset()
            populateValidParams(params)
            def saldoFaixa = new SaldoFaixa(params).save(flush: true)

        then:"It exists"
            SaldoFaixa.count() == 1

        when:"The domain instance is passed to the delete action"
            controller.delete(saldoFaixa)

        then:"The instance is deleted"
            SaldoFaixa.count() == 0
            response.redirectedUrl == '/saldoFaixa/index'
            flash.message != null
    }
}
