import s039.T039hfix
import s039.T039hfixPK
import s493x039.T039HFIX

def list = T039hfix.list(max:1000)
T039HFIX destino

for(T039hfix elementos in list){
    destino = new T039HFIX()
    destino.cd_ar_opr = elementos.id.cdArOpr
    destino.cd_ag = elementos.id.cdAg
    destino.cd_ctr = elementos.id.cdCtr
    destino.nr_ope = elementos.id.nrOpe
    destino.dt_vig_fch = elementos.id.dtVigFch
    destino.cd_atv = elementos.cdAtv
    destino.cd_cat_prd = elementos.cdCatPrd
    destino.cd_ctb_atr = elementos.cdCtbAtr
    destino.cd_ctb_nrm = elementos.cdCtbNrm
    destino.cd_dst_rec = elementos.cdDstRec
    destino.cd_fin_ope_ori = elementos.cdFinOpeOri
    destino.cd_fte_rec = elementos.cdFteRec
    destino.cd_moe = elementos.cdMoe
    destino.cd_moe_ref = elementos.cdMoeRef
    destino.cd_prg_crd = elementos.cdPrgCrd
    destino.cd_rap_atr = elementos.cdRapAtr
    destino.cd_rap_nrm = elementos.cdRapNrm
    destino.cd_rsc_fne = elementos.cdRscFne
    destino.cd_set_atv = elementos.cdSetAtv
    destino.cd_sis = elementos.cdSis
    destino.cd_tp_bnf = elementos.cdTpBnf
    destino.cd_tp_cor = elementos.cdTpCor
    destino.cd_tp_crd = elementos.cdTpCrd
    destino.cd_tp_cta = elementos.cdTpCta
    destino.cd_tp_pes = elementos.cdTpPes
    destino.cd_tp_rec = elementos.cdTpRec
    destino.dh_atz = elementos.dhAtz
    destino.dt_prc = elementos.dtPrc
    destino.id_ctp_bid = elementos.idCtpBid
    destino.id_gar = elementos.idGar
    destino.id_irr = elementos.idIrr
    destino.id_ope_alg = elementos.idOpeAlg
    destino.id_sit_fch = elementos.idSitFch
    destino.id_sma = elementos.idSma
    destino.id_sub = elementos.idSub
    destino.save()
}
    