package bootstrap

class Aluno {
	
	String nome
	String cpf

    static constraints = {
    }
}
