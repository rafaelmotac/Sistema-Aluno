package br.gov.bnb.bank.dados;

import java.util.Collection;

import br.gov.bnb.bank.negocio.Cliente;

public interface IRepositorioClientes extends IRepositorio<Cliente> {

	public Collection<Cliente> getClientes();
}
