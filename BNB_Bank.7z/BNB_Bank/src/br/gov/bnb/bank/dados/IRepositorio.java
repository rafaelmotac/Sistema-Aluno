package br.gov.bnb.bank.dados;

public interface IRepositorio<T> {

	public void inserir(T t);
	public boolean existe(String t);
	public void atualizar(T t);
	public T procurar(String t);
	public void remover(T t);

}
