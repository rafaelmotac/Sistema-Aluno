package br.gov.bnb.bank.dados;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import br.gov.bnb.bank.negocio.Cliente;
import br.gov.bnb.bank.negocio.Endereco;
import br.gov.bnb.bank.negocio.Fachada;
import br.gov.bnb.bank.negocio.TipoCliente;

public class RepositorioClientesFile implements IRepositorioClientes{
		
	private static final String caminhoArq = Fachada.sistemaProperties.getProperty("arquivoCliente");
		
	public RepositorioClientesFile() {
				
	}
	
	@Override
	public void atualizar(Cliente c) {
				
		Cliente cli = procurar(c.getCPF());
		
		if (cli != null){
			remover(cli);
			inserir(c);
		}		
	}

	@Override
	public boolean existe(String cpf) {

		if(procurar(cpf)!= null){
			return true;
		}
		else{			
			return false;
		}
	}

	@Override
	public void inserir(Cliente c) {
		
		Collection<Cliente> clientes = getClientes();
		clientes.add(c);
		setClientes(clientes);
	}

	@Override
	public Cliente procurar(String cpf) {
					
		Collection<Cliente> clientes = getClientes();
		
		for (Iterator<Cliente> iterator = clientes.iterator(); iterator.hasNext();) {
			Cliente c = (Cliente) iterator.next();
			if(c.getCPF().equals(cpf)){
				return c;
			}
		}
		
		return null;
	}

	@Override
	public void remover(Cliente c) {
		
		Collection<Cliente> clientes = getClientes();	
		
		for (Iterator<Cliente> iterator = clientes.iterator(); iterator.hasNext();) {
			Cliente cl = (Cliente) iterator.next();
			if(cl.getCPF().equals(c.getCPF())){
				clientes.remove(cl);
				break;
			}
		}	
		setClientes(clientes);				
	}
	
	public void setClientes(Collection<Cliente> clientes){
		
		FileWriter fout = null;
		BufferedWriter bw = null;
		
		try {
			
			fout = new FileWriter(caminhoArq);			
			bw = new BufferedWriter(fout);
			
			for (Iterator<Cliente> iterator = clientes.iterator(); iterator.hasNext();) {
				Cliente c = (Cliente) iterator.next();
				bw.append(c.getCPF()+";"+c.getNome()+";"+c.getTipo().toString()+"#"+c.getEndereco().getCEP()+";"+c.getEndereco().getRua()+";"+c.getEndereco().getBairro()+";"+c.getEndereco().getComplemento());
				bw.newLine();						
			}			
		} catch (IOException e) {
			
			System.out.println("Arquivo n�o encontrado.");
		} finally{
			
			try {				
				bw.close();
				fout.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}				
	}
	
	public Collection<Cliente> getClientes() {

		Collection<Cliente> clientes = null;		
		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(caminhoArq);
			br = new BufferedReader(fr);
			clientes = new ArrayList<Cliente>();						
			String line = br.readLine();			
						
			while(line != null){
				String [] lineSplit = line.split("#");
				String [] lineCliente = lineSplit[0].split(";");
				String [] lineEndereco = lineSplit[1].split(";");
				
				Endereco endereco = new Endereco(lineEndereco[0],lineEndereco[1],lineEndereco[2],lineEndereco[3]);
				clientes.add(new Cliente(lineCliente[0], lineCliente[1], endereco, TipoCliente.valueOf(lineCliente[2])));						
									
				line = br.readLine();
			}		
			
		} catch (IOException e) {
			System.out.println("Arquivo n�o encontrado.");
		} finally{
			
			try {				
				br.close();
				fr.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
				
		return clientes;	
	}	

}
