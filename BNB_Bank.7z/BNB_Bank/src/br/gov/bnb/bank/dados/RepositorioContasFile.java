package br.gov.bnb.bank.dados;

import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import br.gov.bnb.bank.negocio.ContaAbstrata;

public class RepositorioContasFile implements IRepositorioContas{

	private Map<String, ContaAbstrata> contas;
	private static final String caminhoArq = "C:"+File.separator+"Users"+File.separator+"F158917"+File.separator+"Desktop"+File.separator+"Contas.txt";
	private File f; 
	private FileOutputStream fos;
	
	public RepositorioContasFile() {
		
		contas = new HashMap<String, ContaAbstrata>();
		f = new File("contas.txt"); 
		try {
			fos = new FileOutputStream(f);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	@Override
	public void atualizar(ContaAbstrata c) {

		ContaAbstrata conta = this.contas.get(c.getNumero());
		if(conta != null){
			this.contas.remove(conta.getNumero());
			this.contas.put(c.getNumero(), c);
		}	
	}

	@Override
	public boolean existe(String num) {
		
		if(this.contas.containsKey(num)){
			return true;
		}
		else{			
			return false;
		}			
	}

	public Collection<ContaAbstrata> getContas() {
		
		return this.contas.values();
	}

	@Override
	public void inserir(ContaAbstrata c) {

		FileWriter fout = null;
		BufferedWriter bw = null;
		
		try {
			fout = new FileWriter(caminhoArq, true);
			bw = new BufferedWriter(fout);
			
			bw.append(c.getNumero()+";"+c.getSaldo());
			bw.newLine();
			
		} catch (IOException e) {
			System.out.println("Arquivo n�o encontrado.");
		} finally{
			
			try {
				bw.flush();
				bw.close();
				fout.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}	
		
		contas.put(c.getNumero(), c);		
	}

	@Override
	public ContaAbstrata procurar(String num) {

		if(this.contas.containsKey(num)){
			return this.contas.get(num);
		}
		
		return null;
	}

	@Override
	public void remover(ContaAbstrata c) {
		
		ContaAbstrata conta = this.contas.get(c.getNumero());
		if(conta != null){
			this.contas.remove(conta.getNumero());			
		}			
	}
	
	public void writeFile(File file, ContaAbstrata conta){
			
		FileOutputStream fos = null;
		DataOutputStream dos = null;
			
			try {
				
				fos = new FileOutputStream(file);
				dos = new DataOutputStream(fos);
				
				dos.writeBytes(conta.getNumero());
				dos.writeByte('\n');
				dos.writeBytes(String.valueOf(conta.getSaldo()));
				dos.writeByte('\n');				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				
				try {
					dos.close();
					fos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
								
			}		
		
	}


}
