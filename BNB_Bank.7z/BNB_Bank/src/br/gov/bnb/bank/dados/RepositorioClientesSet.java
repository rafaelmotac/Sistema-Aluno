package br.gov.bnb.bank.dados;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.TreeSet;

import br.gov.bnb.bank.negocio.Cliente;

public class RepositorioClientesSet implements IRepositorioClientes {
	
	private TreeSet<Cliente> clientes;	
		
	public RepositorioClientesSet() {
		
		this.clientes = new TreeSet<Cliente>();
	}
	
	@Override
	public void atualizar(Cliente c) {
				
		Cliente cli = procurar(c.getCPF());
		
		if (cli != null){
			this.clientes.remove(cli);
			inserir(c);
		}		
	}

	@Override
	public boolean existe(String cpf) {

		if(procurar(cpf)!= null){
			return true;
		}
		else{			
			return false;
		}
	}

	@Override
	public void inserir(Cliente c) {
		
		this.clientes.add(c);		
	}

	@Override
	public Cliente procurar(String cpf) {
						 
		Iterator<Cliente> iterator = this.clientes.iterator();
		
		while (iterator.hasNext()) {
			
			Cliente it = iterator.next(); 
		    if(it.getCPF().equals(cpf)){
				
				return it;
			}
		}	
		
		return null;
	}

	@Override
	public void remover(Cliente c) {
		
		Cliente cli = procurar(c.getCPF());
		if (cli != null){
			this.clientes.remove(cli);
		}		
	}
	
	public Collection<Cliente> getClientes() {

		Collection<Cliente> col = new ArrayList<Cliente>();
		
		for (Cliente cli : this.clientes){
			col.add(cli);
		}
		
		return col;	
	}	
}
