package br.gov.bnb.bank.negocio;
import br.gov.bnb.bank.dados.IRepositorio;
import br.gov.bnb.bank.dados.IRepositorioClientes;
import br.gov.bnb.bank.exceptions.ErroAcessoRepositorioException;

public class CadastroClientes implements ICadastro<Cliente>{
	
	private IRepositorioClientes clientes;	

	public CadastroClientes(IRepositorioClientes r) {
		
		this.clientes = r;
	}
	
	public void atualizar(Cliente c) throws ErroAcessoRepositorioException{
		
		if (c == null){ throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("clienteNulo"));}
		
		if(existe(c.getCPF())){
			clientes.atualizar(c);
		}
		else{
			throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("clienteInexistente"));
		}
	}	
	
	public void cadastrar(Cliente c) throws ErroAcessoRepositorioException{
		
		if (c == null){ throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("clienteNulo"));}
		
		if (!existe(c.getCPF())){
			
			clientes.inserir(c);			
		}
		else{
			
			throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("clienteExistente"));
		}		
	}
	
	public void descadastrar(String n) throws ErroAcessoRepositorioException{
		
		if(existe(n)){
			
			Cliente c = procurar(n);
			clientes.remover(c);
		}
		else {
			throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("clienteExistente"));
		}
	}
	
	public boolean existe(String cpf){
		
		return clientes.existe(cpf);
	}
	
	public Cliente procurar(String n){
		
		return clientes.procurar(n);
	}
	
	public void listar(){
		
		for (Cliente c : clientes.getClientes()) {
			
			if(c!=null){
				
				System.out.println("Nome "+ c.getNome() +" CPF: " + c.getCPF()+" CEP: "+ c.getEndereco().getCEP()+" Tipo: "+ c.getTipo() );
			}			
		}		
	}	
	
	public IRepositorio<Cliente> getClientes() {
		return clientes;
	}
}
