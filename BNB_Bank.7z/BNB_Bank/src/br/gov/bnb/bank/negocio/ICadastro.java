package br.gov.bnb.bank.negocio;

import br.gov.bnb.bank.exceptions.ErroAcessoRepositorioException;


public interface ICadastro<T> {
	
	public void atualizar(T t) throws ErroAcessoRepositorioException;	
	public void cadastrar(T t) throws ErroAcessoRepositorioException;	
	public void descadastrar(String arg) throws ErroAcessoRepositorioException;	
	public boolean existe(String arg);	
	public T procurar(String arg);	
	public void listar();		
}
