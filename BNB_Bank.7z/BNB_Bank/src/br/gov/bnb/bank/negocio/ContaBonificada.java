package br.gov.bnb.bank.negocio;


public class ContaBonificada extends Conta {

	private double bonus;
	
	public ContaBonificada(String numero, Cliente c) {
		super(numero, c);
		// TODO Stub de construtor gerado automaticamente
	}

	public ContaBonificada(String numero, double valor, Cliente c) {
		super(numero, valor, c);
		// TODO Stub de construtor gerado automaticamente
	}
	
	public void renderBonus(){
		
		super.creditar(this.bonus);
		this.bonus = 0;
	}
	
	public void creditar(double valor){
		this.bonus = this.bonus + (valor*0.01);
		super.creditar(valor);
	}
	
	public double getBonus() {
		return this.bonus;
	}

	public void setBonus(double bonus) {
		this.bonus = bonus;
	}

}
