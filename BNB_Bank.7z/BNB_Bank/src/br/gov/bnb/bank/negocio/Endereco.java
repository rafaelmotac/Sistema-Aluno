package br.gov.bnb.bank.negocio;

public class Endereco {
	
	private String CEP;
	private String rua;
	private String bairro;
	private String complemento;
	
	public Endereco(String cep, String rua, String bairro, String complemento) {
		
		setCEP(cep);
		setRua(rua);
		setBairro(bairro);
		setComplemento(complemento);
	}
	
	public String getCEP() {
		return CEP;
	}
	public void setCEP(String cep) {
		CEP = cep;
	}
	public String getRua() {
		return rua;
	}
	public void setRua(String rua) {
		this.rua = rua;
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	public String getComplemento() {
		return complemento;
	}
	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}
}
