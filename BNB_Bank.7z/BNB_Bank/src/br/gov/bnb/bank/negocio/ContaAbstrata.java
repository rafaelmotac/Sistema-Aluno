package br.gov.bnb.bank.negocio;

import br.gov.bnb.bank.exceptions.ErroAcessoRepositorioException;

public abstract class ContaAbstrata {

	private String numero;
	private double saldo;
	private Cliente cliente;
	
	public ContaAbstrata(String num, Cliente c) {
		numero = num;
		cliente = c;
		saldo = 0;
	}
	
	public ContaAbstrata(String num, double s, Cliente c) {
		numero = num;
		saldo = s;
		cliente = c;
	}
	
	public Cliente getCliente(){
		return cliente;
	}
	
	public String getNumero() {
		return numero;
	}
	
	public double getSaldo() {
		return saldo;
	}
	
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	
	public void setNumero(String num) {
		this.numero = num;
	}
	
	public void setSaldo(double valor) {
		saldo = valor;
	}
	public void creditar(double valor){
		saldo = saldo + valor;
	}
	
	public abstract void debitar(double valor) throws ErroAcessoRepositorioException;
	
	public void transferir(ContaAbstrata c, double v) throws ErroAcessoRepositorioException{
		
		this.debitar(v);
		c.creditar(v);
	}	
}
