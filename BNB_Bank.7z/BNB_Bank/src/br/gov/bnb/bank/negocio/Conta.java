package br.gov.bnb.bank.negocio;

import br.gov.bnb.bank.exceptions.ErroAcessoRepositorioException;

public class Conta extends ContaAbstrata{


	public Conta(String numero, Cliente c) {
		
		super(numero, c);
	}
	
	public Conta(String numero, double valor, Cliente c) {
		
		super(numero, valor, c);
	}	
	
	public void debitar(double valor) throws ErroAcessoRepositorioException{	
		
		double saldo = getSaldo();
		if(valor <= saldo){
			setSaldo(saldo - valor);
		} 
		else {

			throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("saldoInsuficiente"));
		}				
	}	
}
