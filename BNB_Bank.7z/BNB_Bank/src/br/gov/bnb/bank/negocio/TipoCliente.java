package br.gov.bnb.bank.negocio;

public enum TipoCliente {
	STANDARD,
	VIP,
	CLASS
}
