package br.gov.bnb.bank.file;

import java.io.File;
import java.util.Date;

public class TesteArquivo {
	
	
	public static void main(java.lang.String[] args) {
		
		detalharArquivo();
		
		listarDiretorio();
	}
	
	public static void detalharArquivo() {
		
		System.out.println("***Detalhar Arquivo***\n");
		
		String nomeArquivo = "C:\\Users\\F158917\\Desktop"; 
		
		File arq = new File(nomeArquivo);
		
		if (!arq.exists()) {
			
			System.out.print("Arquivo nao existe: "+nomeArquivo);
			
		} else {
			System.out.println("Nome: " + arq.getName());
			System.out.println("Caminho absoluto: " +
					arq.getAbsolutePath());
			System.out.println("Tamanho:"+arq.length()+"bytes");
			long horaMod = arq.lastModified();
			System.out.println("Hora de modificacao: " +
					new Date(horaMod));
		}
	}
	
	public static void listarDiretorio() {

		System.out.println("\n***Listar Diret�rio***");
		
		String nomeDiretorio = ".";
		File dir = new File(nomeDiretorio);
		if (!dir.exists()) {
			System.out.println("\nDiretorio " +
					dir.getAbsolutePath() + " nao encontrado");
		} else if (dir.isDirectory()) {
			String[] listaArquivos = dir.list();
			System.out.println("\nArquivos do diretorio " +
					dir.getAbsolutePath());
			
			if (listaArquivos != null) {
				for(int i=0; i < listaArquivos.length; i++)
					System.out.println(listaArquivos[i]);

			}
		}
	}
	
}