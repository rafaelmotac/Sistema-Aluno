package br.gov.bnb.bank.exceptions;

@Deprecated
public class ClienteInexistenteException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1153611392466341527L;

	public ClienteInexistenteException(String msg) {
		super(msg);
	}
}
