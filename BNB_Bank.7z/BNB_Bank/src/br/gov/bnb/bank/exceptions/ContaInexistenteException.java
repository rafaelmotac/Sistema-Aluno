package br.gov.bnb.bank.exceptions;

@Deprecated
public class ContaInexistenteException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1964688212223466686L;

	public ContaInexistenteException(String msg) {
		super(msg);
	}
	
}
