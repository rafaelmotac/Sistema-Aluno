package br.gov.bnb.bank.exceptions;

@Deprecated
public class ContaExistenteException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3870375906475758259L;

	public ContaExistenteException(String msg) {
		super(msg);
	}

}
