package bnb.gov.br.teste;

public class AgendaTelefonicaComMemoryLeak {

	private String agendaTelefonica[];

	private int numeroRegistros;

	
	public static void main(String [] args){
		
		AgendaTelefonicaComMemoryLeak agenda = new AgendaTelefonicaComMemoryLeak();
		agenda.AdicionarContato("Z�");
	}
	
	public AgendaTelefonicaComMemoryLeak(){

		agendaTelefonica = new String[10];
		numeroRegistros = 0;
	}

	public void AdicionarContato(String contato){

		if (numeroRegistros<agendaTelefonica.length) {

			agendaTelefonica[numeroRegistros++] = contato;

		}
	}

	public void removerContato(String contato){

		int found = -1;

		for (int i = 0; i < numeroRegistros; i++) {

			if (agendaTelefonica[i].equals(contato)) {

				found = i;

			}

		}

		if(found != -1){

			numeroRegistros--;

			for (int i = 0; i < numeroRegistros; i++) {

				agendaTelefonica[i] =agendaTelefonica[i+1];

			}

		}

	}

}

